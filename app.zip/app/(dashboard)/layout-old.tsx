"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  BarChart3,
  CalendarRange,
  GraduationCap,
  LayoutDashboard,
  LogOut,
  Settings,
  UserRound,
  UsersRound,
  UserRoundCog,
} from "lucide-react";

const menuItems = [
  {
    label: "Dashboard",
    href: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    label: "Lead Management",
    href: "/leads",
    icon: UsersRound,
  },
  {
    label: "Student Management",
    href: "/students",
    icon: GraduationCap,
  },
  {
    label: "Batch Management",
    href: "/batches",
    icon: CalendarRange,
  },
  { label: "Staff Management", 
    href: "/staff",
    icon: UserRoundCog,
  },
  {
    label: "Reports",
    href: "/reports",
    icon: BarChart3,
  },
  {
    label: "Settings",
    href: "/settings",
    icon: Settings,
  },
];

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();

  function handleLogout() {
    router.push("/login");
  }

  return (
    <div className="flex min-h-screen bg-white">
      {/* =====================================================
          SIDEBAR
      ===================================================== */}

      <aside className="sticky top-0 flex h-screen w-64 shrink-0 flex-col border-r border-neutral-200 bg-white">
        {/* ===================================================
            TOP - LOGO
        =================================================== */}

          <div className="shrink-0 border-b border-neutral-200 px-5 py-5">
            <div className="flex items-center gap-3">
              {/* LOGO - NO BACKGROUND */}
              <img
                src="/icon.png"
                alt="JET Skills Logo"
                className="h-12 w-auto shrink-0 object-contain"
              />

              <div>
                <div className="text-lg font-semibold text-neutral-900">
                  JET Skills
                </div>

                <div className="text-xs text-neutral-500">
                  Management Information System
                </div>
              </div>
            </div>
          </div>

        {/* ===================================================
            MIDDLE - NAVIGATION
        =================================================== */}

        <nav className="min-h-0 flex-1 overflow-y-auto px-3 py-5">
          <div className="space-y-1.5">
            {menuItems.map((item) => {
              const Icon = item.icon;

              const active =
                pathname === item.href ||
                pathname.startsWith(`${item.href}/`);

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex h-11 items-center gap-3 rounded-lg px-3.5 text-sm font-medium transition ${
                    active
                      ? "border border-blue-100 bg-blue-50 text-blue-700"
                      : "border border-transparent text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900"
                  }`}
                >
                  <Icon
                    size={18}
                    strokeWidth={1.8}
                    className={
                      active
                        ? "text-blue-600"
                        : "text-neutral-400"
                    }
                  />

                  <span>{item.label}</span>
                </Link>
              );
            })}
          </div>
        </nav>

        {/* ===================================================
            BOTTOM - USER + LOGOUT
        =================================================== */}

        <div className="shrink-0 border-t border-neutral-100 bg-white p-3">
          {/* USER */}

          <div className="mb-2 flex items-center gap-3 rounded-lg bg-neutral-50 px-3 py-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-green-100 bg-green-50 text-green-700">
              <UserRound
                size={17}
                strokeWidth={1.8}
              />
            </div>

            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-neutral-800">
                Admin
              </p>

              <p className="truncate text-xs text-neutral-400">
                Administrator
              </p>
            </div>
          </div>

          {/* LOGOUT */}

          <button
            type="button"
            onClick={handleLogout}
            className="flex h-10 w-full items-center gap-3 rounded-lg border border-red-100 bg-red-50 px-3.5 text-sm font-medium text-red-600 transition hover:border-red-200 hover:bg-red-100"
          >
            <LogOut
              size={17}
              strokeWidth={1.8}
            />

            Logout
          </button>
        </div>
      </aside>

      {/* =====================================================
          PAGE CONTENT
      ===================================================== */}

      <main className="min-w-0 flex-1 bg-white">
        {children}
      </main>
    </div>
  );
}