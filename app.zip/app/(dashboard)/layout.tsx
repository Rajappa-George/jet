"use client";

import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import {
  LayoutDashboard,
  UsersRound,
  GraduationCap,
  CalendarRange,
  BarChart3,
  Settings,
  LogOut,
  UserRound,
  UserRoundCog,
  ChevronDown,
  ChevronRight,
  Circle,
} from "lucide-react";

const mainMenu = [
  { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { label: "Lead Management", href: "/leads", icon: UsersRound },
  { label: "Student Management", href: "/students", icon: GraduationCap },
  { label: "Batch Management", href: "/batches", icon: CalendarRange },
  { label: "Staff Management", href: "/staff", icon: UserRoundCog },
  { label: "Reports", href: "/reports", icon: BarChart3 },
];

const settingsChildren = [
  { label: "Institute", tab: "institute" },
  { label: "Branches", tab: "branches" },
  { label: "Courses", tab: "courses" },
  { label: "Users & Roles", tab: "users" },
  { label: "Monthly Targets", tab: "targets" },
];

export default function DashboardLayout({
  children,
}: {
  children: ReactNode;
}) {
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();

  const isSettingsRoute = pathname.startsWith("/settings");
  const activeSettingsTab = searchParams.get("tab") || "institute";

  const [settingsOpen, setSettingsOpen] = useState(isSettingsRoute);

  useEffect(() => {
    if (isSettingsRoute) {
      setSettingsOpen(true);
    }
  }, [isSettingsRoute]);

  function goToSettings(tab = "institute") {
    setSettingsOpen(true);
    router.push(`/settings?tab=${tab}`);
  }

  return (
    <div className="flex min-h-screen bg-neutral-50">
      <aside className="sticky top-0 flex h-screen w-64 shrink-0 flex-col border-r border-neutral-200 bg-white">
        {/* BRAND */}
        <div className="shrink-0 border-b border-neutral-200 px-5 py-5">
          <div className="flex items-center gap-3">
            <img
              src="/icon.png"
              alt="JET Skills Logo"
              className="h-12 w-auto shrink-0 object-contain"
            />
            <div>
              <div className="text-lg font-semibold text-neutral-900">
                JET MIS
              </div>
              <div className="text-xs text-neutral-500">
                Institute Management
              </div>
            </div>
          </div>
        </div>

        {/* MAIN NAV */}
        <nav className="min-h-0 flex-1 overflow-y-auto px-3 py-4">
          <div className="space-y-1">
            {mainMenu.map((item) => {
              const Icon = item.icon;
              const active =
                pathname === item.href ||
                (item.href !== "/dashboard" &&
                  pathname.startsWith(`${item.href}/`));

              return (
                <button
                  key={item.href}
                  type="button"
                  onClick={() => router.push(item.href)}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition ${
                    active
                      ? "bg-blue-50 text-blue-700"
                      : "text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900"
                  }`}
                >
                  <Icon size={18} />
                  <span>{item.label}</span>
                </button>
              );
            })}

            {/* SETTINGS PARENT */}
            <div>
              <button
                type="button"
                onClick={() => {
                  if (!settingsOpen) {
                    goToSettings(activeSettingsTab);
                  } else {
                    setSettingsOpen(false);
                  }
                }}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition ${
                  isSettingsRoute
                    ? "bg-blue-50 text-blue-700"
                    : "text-neutral-600 hover:bg-neutral-50 hover:text-neutral-900"
                }`}
              >
                <Settings size={18} />
                <span className="flex-1">Settings</span>
                {settingsOpen ? (
                  <ChevronDown size={16} />
                ) : (
                  <ChevronRight size={16} />
                )}
              </button>

              {/* SETTINGS CHILD MENU */}
              {settingsOpen && (
                <div className="mt-1 space-y-0.5 border-l border-neutral-200 pl-3 ml-5">
                  {settingsChildren.map((item) => {
                    const active =
                      isSettingsRoute &&
                      activeSettingsTab === item.tab;

                    return (
                      <button
                        key={item.tab}
                        type="button"
                        onClick={() => goToSettings(item.tab)}
                        className={`flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm transition ${
                          active
                            ? "bg-blue-50 text-blue-700"
                            : "text-neutral-500 hover:bg-neutral-50 hover:text-neutral-900"
                        }`}
                      >
                        <Circle
                          size={10}
                          className={
                            active
                              ? "fill-blue-500 text-blue-500"
                              : "text-neutral-400"
                          }
                        />
                        <span>{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </nav>

        {/* USER / LOGOUT */}
        <div className="shrink-0 border-t border-neutral-200 p-3">
          <div className="mb-2 flex items-center gap-3 rounded-lg px-3 py-2.5">
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-neutral-100 text-neutral-600">
              <UserRound size={18} />
            </div>
            <div className="min-w-0">
              <div className="truncate text-sm font-medium text-neutral-900">
                Admin
              </div>
              <div className="truncate text-xs text-neutral-500">
                Administrator
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={() => router.push("/login")}
            className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-red-600 transition hover:bg-red-50"
          >
            <LogOut size={18} />
            Logout
          </button>
        </div>
      </aside>

      <main className="min-w-0 flex-1">{children}</main>
    </div>
  );
}
