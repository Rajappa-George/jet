"use client";

import {
  Banknote,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  CircleDollarSign,
  Download,
  EllipsisVertical,
  Eye,
  GraduationCap,
  Pencil,
  RotateCcw,
  Search,
  UserRoundCheck,
  UserRoundX,
  UsersRound,
  WalletCards,
  X,
} from "lucide-react";
import {
  FormEvent,
  MouseEvent as ReactMouseEvent,
  ReactNode,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

type StudentStatus = "Active" | "Completed" | "Dropped";
type FeeStatus = "Fully Paid" | "Fee Due" | "Overdue";
type HoCertificateStatus = "Ongoing" | "Pending" | "Generated" | "N/A";
type BranchCertificateStatus = "Ongoing" | "Pending" | "Issued" | "N/A";
type PaymentMode = "Cash" | "UPI" | "Opening";

type Installment = {
  amount: number;
  date: string;
  paidAmount: number;
};

type Payment = {
  id: string;
  receiptNo: string;
  date: string;
  amount: number;
  mode: PaymentMode;
  reference?: string;
};

type Student = {
  admissionId: string;
  admissionDate: string;
  endDate: string;
  studentName: string;
  dob: string;
  contactNo: string;
  email: string;
  guardianName: string;
  guardianContact: string;
  motherName: string;
  aadhaarNo: string;
  qualification: string;
  course: string;
  totalFee: number;
  studentStatus: StudentStatus;
  hoCertificateStatus: HoCertificateStatus;
  branchCertificateStatus: BranchCertificateStatus;
  installments: Installment[];
  payments: Payment[];
  dropReason?: string;
};

type SortKey =
  | "admissionId"
  | "studentName"
  | "contactNo"
  | "course"
  | "admissionDate"
  | "endDate"
  | "studentStatus"
  | "feeStatus"
  | "hoCertificateStatus"
  | "branchCertificateStatus";

type SortDirection = "asc" | "desc";
type ActionMenu = { student: Student; x: number; y: number } | null;

const sampleStudents: Student[] = [
  {
    admissionId: "TRY/SEP001",
    admissionDate: "2026-09-01",
    endDate: "2026-12-31",
    studentName: "Arun Kumar",
    dob: "2002-06-12",
    contactNo: "9876543210",
    email: "arun@example.com",
    guardianName: "Ramesh Kumar",
    guardianContact: "9876500010",
    motherName: "Lakshmi",
    aadhaarNo: "123456789012",
    qualification: "B.E",
    course: "Full Stack Development",
    totalFee: 40000,
    studentStatus: "Active",
    hoCertificateStatus: "Ongoing",
    branchCertificateStatus: "Ongoing",
    hoCertificateStatus: "Ongoing",
    branchCertificateStatus: "Ongoing",
    hoCertificateStatus: "Ongoing",
    branchCertificateStatus: "Ongoing",
    installments: [
      { amount: 10000, date: "2026-09-10", paidAmount: 10000 },
      { amount: 10000, date: "2026-10-10", paidAmount: 5000 },
      { amount: 10000, date: "2026-11-10", paidAmount: 0 },
    ],
    payments: [
      {
        id: "PAY-001",
        receiptNo: "RCPT/2026/0001",
        date: "2026-09-01",
        amount: 15000,
        mode: "UPI",
        reference: "UPI001ARUN",
      },
    ],
  },
  {
    admissionId: "TRY/SEP002",
    admissionDate: "2026-08-20",
    endDate: "2026-09-03",
    studentName: "Priya S",
    dob: "2003-02-18",
    contactNo: "9876543211",
    email: "priya@example.com",
    guardianName: "Suresh",
    guardianContact: "9876500011",
    motherName: "Meena",
    aadhaarNo: "123456789013",
    qualification: "B.Com",
    course: "Beautician",
    totalFee: 22000,
    studentStatus: "Completed",
    hoCertificateStatus: "Generated",
    branchCertificateStatus: "Pending",
    installments: [],
    payments: [
      {
        id: "PAY-002",
        receiptNo: "RCPT/2026/0002",
        date: "2026-08-20",
        amount: 22000,
        mode: "Cash",
      },
    ],
  },
  {
    admissionId: "TRY/SEP003",
    admissionDate: "2026-08-12",
    endDate: "2026-08-28",
    studentName: "Deepa R",
    dob: "2001-11-03",
    contactNo: "9876543212",
    email: "deepa@example.com",
    guardianName: "Ravi",
    guardianContact: "9876500012",
    motherName: "Kavitha",
    aadhaarNo: "123456789014",
    qualification: "B.Sc",
    course: "Fashion Designing",
    totalFee: 32000,
    studentStatus: "Dropped",
    hoCertificateStatus: "N/A",
    branchCertificateStatus: "N/A",
    installments: [
      { amount: 10000, date: "2026-08-20", paidAmount: 7000 },
      { amount: 10000, date: "2026-09-20", paidAmount: 0 },
    ],
    payments: [
      {
        id: "PAY-003",
        receiptNo: "RCPT/2026/0003",
        date: "2026-08-12",
        amount: 12000,
        mode: "Cash",
      },
    ],
    dropReason: "Personal reason",
  },
  {
    admissionId: "TRY/SEP004",
    admissionDate: "2026-09-03",
    endDate: "2026-11-30",
    studentName: "Karthik R",
    dob: "2002-03-21",
    contactNo: "9876543213",
    email: "karthik@example.com",
    guardianName: "Rajendran",
    guardianContact: "9876500013",
    motherName: "Selvi",
    aadhaarNo: "123456789015",
    qualification: "B.Sc",
    course: "Python Programming",
    totalFee: 28000,
    studentStatus: "Active",
    installments: [
      { amount: 14000, date: "2026-09-20", paidAmount: 0 },
      { amount: 14000, date: "2026-10-20", paidAmount: 0 },
    ],
    payments: [],
  },
  {
    admissionId: "TRY/SEP005",
    admissionDate: "2026-09-04",
    endDate: "2026-11-30",
    studentName: "Mohamed Irfan",
    dob: "2001-07-09",
    contactNo: "9876543214",
    email: "irfan@example.com",
    guardianName: "Mohamed Ali",
    guardianContact: "9876500014",
    motherName: "Fathima",
    aadhaarNo: "123456789016",
    qualification: "BCA",
    course: "UI/UX Designing",
    totalFee: 30000,
    studentStatus: "Active",
    installments: [
      { amount: 15000, date: "2026-09-15", paidAmount: 0 },
      { amount: 15000, date: "2026-10-15", paidAmount: 0 },
    ],
    payments: [],
  },
];

function getLocalDate() {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, "0");
  const d = String(now.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function formatDate(value: string) {
  if (!value) return "-";
  return new Date(`${value}T00:00:00`).toLocaleDateString("en-GB");
}

function money(value: number) {
  return `₹${Math.max(0, value).toLocaleString("en-IN")}`;
}

function totalPaid(student: Student) {
  return student.payments.reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
}

function balance(student: Student) {
  return Math.max(0, student.totalFee - totalPaid(student));
}

function getFeeStatus(student: Student): FeeStatus {
  if (balance(student) <= 0) return "Fully Paid";
  const today = getLocalDate();
  const overdue = student.installments.some(
    (item) => item.date && item.date < today && item.paidAmount < item.amount
  );
  return overdue ? "Overdue" : "Fee Due";
}

function nextDue(student: Student) {
  return [...student.installments]
    .filter((item) => item.paidAmount < item.amount)
    .sort((a, b) => a.date.localeCompare(b.date))[0];
}

function uniquePaymentId() {
  return `PAY-${Date.now()}-${Math.random().toString(36).slice(2, 7).toUpperCase()}`;
}

function nextReceiptNo(students: Student[]) {
  const year = new Date().getFullYear();
  const count = students.reduce((sum, s) => sum + s.payments.length, 0) + 1;
  return `RCPT/${year}/${String(count).padStart(4, "0")}`;
}

function normalizeHoCertificateStatus(
  studentStatus: StudentStatus,
  value: unknown
): HoCertificateStatus {
  if (studentStatus === "Active") return "Ongoing";
  if (studentStatus === "Dropped") return "N/A";
  return value === "Generated" ? "Generated" : "Pending";
}

function normalizeBranchCertificateStatus(
  studentStatus: StudentStatus,
  hoStatus: HoCertificateStatus,
  value: unknown
): BranchCertificateStatus {
  if (studentStatus === "Active") return "Ongoing";
  if (studentStatus === "Dropped") return "N/A";
  if (hoStatus !== "Generated") return "Pending";
  return value === "Issued" ? "Issued" : "Pending";
}

function normalizeSavedStudent(item: any): Student {
  const legacyPaid = Number(item.paid || 0);
  const normalizedStudentStatus: StudentStatus =
    item.studentStatus === "Completed" || item.studentStatus === "Dropped"
      ? item.studentStatus
      : "Active";
  const normalizedHoStatus = normalizeHoCertificateStatus(
    normalizedStudentStatus,
    item.hoCertificateStatus
  );
  const normalizedBranchStatus = normalizeBranchCertificateStatus(
    normalizedStudentStatus,
    normalizedHoStatus,
    item.branchCertificateStatus
  );
  const savedPayments: Payment[] = Array.isArray(item.payments)
    ? item.payments
    : legacyPaid > 0
      ? [
          {
            id: uniquePaymentId(),
            receiptNo: "OPENING",
            date: item.admissionDate || getLocalDate(),
            amount: legacyPaid,
            mode: "Opening",
          },
        ]
      : [];

  return {
    admissionId: item.admissionId || item.id || "",
    admissionDate: item.admissionDate || getLocalDate(),
    endDate: item.endDate || "",
    studentName: item.studentName || item.name || "",
    dob: item.dob || "",
    contactNo: item.contactNo || item.contact || "",
    email: item.email || "",
    guardianName: item.guardianName || item.fatherName || "",
    guardianContact: item.guardianContact || "",
    motherName: item.motherName || "",
    aadhaarNo: item.aadhaarNo || item.aadhaar || "",
    qualification: item.qualification || "",
    course: item.course || "",
    totalFee: Number(item.totalFee || item.committedFee || 0),
    studentStatus: normalizedStudentStatus,
    hoCertificateStatus: normalizedHoStatus,
    branchCertificateStatus: normalizedBranchStatus,
    installments: Array.isArray(item.installments)
      ? item.installments.map((x: any) => ({
          amount: Number(x.amount ?? x.commitAmount ?? 0),
          date: x.date ?? x.commitDate ?? "",
          paidAmount: Number(x.paidAmount || 0),
        }))
      : [],
    payments: savedPayments,
    dropReason: item.dropReason || "",
  };
}

export default function StudentManagementPage() {
  const [students, setStudents] = useState<Student[]>(sampleStudents);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | StudentStatus>("All");
  const [courseFilter, setCourseFilter] = useState("All");
  const [feeFilter, setFeeFilter] = useState<"All" | FeeStatus>("All");
  const [sortKey, setSortKey] = useState<SortKey>("admissionDate");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");
  const [actionMenu, setActionMenu] = useState<ActionMenu>(null);
  const actionMenuRef = useRef<HTMLDivElement | null>(null);

  const [viewStudent, setViewStudent] = useState<Student | null>(null);
  const [editStudent, setEditStudent] = useState<Student | null>(null);
  const [feeStudent, setFeeStudent] = useState<Student | null>(null);

  useEffect(() => {
    try {
      const saved = JSON.parse(localStorage.getItem("jet-mis-admissions") || "[]");
      if (Array.isArray(saved) && saved.length) {
        setStudents(saved.map(normalizeSavedStudent).filter((s) => s.admissionId));
      }
    } catch {
      // Keep sample data if local storage is unavailable/corrupted.
    }
  }, []);

  function persist(updated: Student[]) {
    setStudents(updated);
    localStorage.setItem("jet-mis-admissions", JSON.stringify(updated));
  }

  function replaceStudent(originalId: string, updatedStudent: Student) {
    const next = students.map((student) =>
      student.admissionId === originalId ? updatedStudent : student
    );
    persist(next);
    setViewStudent((current) =>
      current?.admissionId === originalId ? updatedStudent : current
    );
    setFeeStudent((current) =>
      current?.admissionId === originalId ? updatedStudent : current
    );
  }

  const activeStudents = students.filter((s) => s.studentStatus === "Active").length;
  const completedStudents = students.filter((s) => s.studentStatus === "Completed").length;
  const droppedStudents = students.filter((s) => s.studentStatus === "Dropped").length;

  const courseOptions = useMemo(
    () => Array.from(new Set(students.map((s) => s.course).filter(Boolean))).sort(),
    [students]
  );

  const filteredStudents = useMemo(() => {
    const term = search.trim().toLowerCase();
    const filtered = students.filter((student) => {
      const matchesSearch = [
        student.admissionId,
        student.studentName,
        student.contactNo,
        student.course,
      ]
        .join(" ")
        .toLowerCase()
        .includes(term);
      return (
        matchesSearch &&
        (statusFilter === "All" || student.studentStatus === statusFilter) &&
        (courseFilter === "All" || student.course === courseFilter) &&
        (feeFilter === "All" || getFeeStatus(student) === feeFilter)
      );
    });

    filtered.sort((a, b) => {
      let first: string = "";
      let second: string = "";
      if (sortKey === "studentStatus") {
        first = a.studentStatus;
        second = b.studentStatus;
      } else if (sortKey === "feeStatus") {
        first = getFeeStatus(a);
        second = getFeeStatus(b);
      } else {
        first = String(a[sortKey]);
        second = String(b[sortKey]);
      }
      const result = first.localeCompare(second, undefined, {
        numeric: true,
        sensitivity: "base",
      });
      return sortDirection === "asc" ? result : -result;
    });
    return filtered;
  }, [students, search, statusFilter, courseFilter, feeFilter, sortKey, sortDirection]);

  function handleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDirection((current) => (current === "asc" ? "desc" : "asc"));
      return;
    }
    setSortKey(key);
    setSortDirection("asc");
  }

  function handleDownloadExcel() {
    if (!filteredStudents.length) {
      alert("No student data available to download.");
      return;
    }
    const headers = [
      "Admission ID",
      "Student Name",
      "Contact No",
      "Course",
      "Admission Date",
      "End Date",
      "Student Status",
      "Fee Status",
      "HO Certificate",
      "Branch Certificate",
      "Total Fee",
      "Paid",
      "Balance",
    ];
    const rows = filteredStudents.map((student) => [
      student.admissionId,
      student.studentName,
      student.contactNo,
      student.course,
      formatDate(student.admissionDate),
      formatDate(student.endDate),
      student.studentStatus,
      getFeeStatus(student),
      student.hoCertificateStatus,
      student.branchCertificateStatus,
      student.totalFee,
      totalPaid(student),
      balance(student),
    ]);
    const csv = [
      headers.join(","),
      ...rows.map((row) =>
        row.map((value) => `"${String(value).replace(/"/g, '""')}"`).join(",")
      ),
    ].join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `JET-MIS-Students-${getLocalDate()}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  function openActionMenu(student: Student, x: number, y: number) {
    const width = 230;
    const height = 260;
    const padding = 10;
    setActionMenu({
      student,
      x: Math.max(padding, Math.min(x, window.innerWidth - width - padding)),
      y: Math.max(padding, Math.min(y, window.innerHeight - height - padding)),
    });
  }

  function handleActionButton(event: ReactMouseEvent<HTMLButtonElement>, student: Student) {
    event.stopPropagation();
    const rect = event.currentTarget.getBoundingClientRect();
    openActionMenu(student, rect.right - 230, rect.bottom + 6);
  }

  function handleRightClick(event: ReactMouseEvent<HTMLTableRowElement>, student: Student) {
    event.preventDefault();
    openActionMenu(student, event.clientX, event.clientY);
  }

  useEffect(() => {
    function close(event: MouseEvent) {
      if (actionMenuRef.current && !actionMenuRef.current.contains(event.target as Node)) {
        setActionMenu(null);
      }
    }
    function escape(event: KeyboardEvent) {
      if (event.key === "Escape") setActionMenu(null);
    }
    document.addEventListener("mousedown", close);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("mousedown", close);
      document.removeEventListener("keydown", escape);
    };
  }, []);

  function changeStatus(student: Student, status: StudentStatus) {
    let dropReason = student.dropReason || "";
    if (status === "Dropped") {
      const reason = window.prompt("Reason for dropping this student:", dropReason);
      if (reason === null) return;
      if (!reason.trim()) {
        alert("Drop reason is required.");
        return;
      }
      dropReason = reason.trim();
    } else {
      const label = status === "Completed" ? "Mark this student as Completed?" : "Reactivate this student?";
      if (!window.confirm(label)) return;
    }
    const certificateState =
      status === "Active"
        ? {
            hoCertificateStatus: "Ongoing" as HoCertificateStatus,
            branchCertificateStatus: "Ongoing" as BranchCertificateStatus,
          }
        : status === "Dropped"
          ? {
              hoCertificateStatus: "N/A" as HoCertificateStatus,
              branchCertificateStatus: "N/A" as BranchCertificateStatus,
            }
          : {
              hoCertificateStatus: "Pending" as HoCertificateStatus,
              branchCertificateStatus: "Pending" as BranchCertificateStatus,
            };

    const updated = {
      ...student,
      studentStatus: status,
      dropReason,
      endDate:
        status === "Completed" || status === "Dropped"
          ? getLocalDate()
          : student.endDate,
      ...certificateState,
    };
    replaceStudent(student.admissionId, updated);
    setActionMenu(null);
    alert(`Student status updated to ${status}.`);
  }

  function updateCertificateStatus(
    student: Student,
    area: "HO" | "Branch",
    value: HoCertificateStatus | BranchCertificateStatus
  ) {
    if (student.studentStatus !== "Completed") {
      alert("Certificate status can be updated only for completed students.");
      return;
    }

    let updated = { ...student };

    if (area === "HO") {
      const hoValue = value as HoCertificateStatus;
      if (hoValue !== "Pending" && hoValue !== "Generated") return;

      if (
        hoValue === "Pending" &&
        student.branchCertificateStatus === "Issued"
      ) {
        alert(
          "HO Certificate cannot be moved back to Pending after the Branch has issued it."
        );
        return;
      }

      updated = {
        ...updated,
        hoCertificateStatus: hoValue,
        branchCertificateStatus:
          hoValue === "Generated"
            ? updated.branchCertificateStatus
            : "Pending",
      };
    } else {
      const branchValue = value as BranchCertificateStatus;
      if (branchValue !== "Pending" && branchValue !== "Issued") return;

      if (
        branchValue === "Issued" &&
        student.hoCertificateStatus !== "Generated"
      ) {
        alert(
          "Branch Certificate can be marked Issued only after HO status is Generated."
        );
        return;
      }

      updated = {
        ...updated,
        branchCertificateStatus: branchValue,
      };
    }

    replaceStudent(student.admissionId, updated);
  }

  function SortHeader({ label, column }: { label: string; column: SortKey }) {
    const active = sortKey === column;
    return (
      <button
        type="button"
        onClick={() => handleSort(column)}
        className="flex items-center gap-1.5 whitespace-nowrap font-semibold text-neutral-700 transition hover:text-blue-700"
      >
        {label}
        {!active && <ChevronDown size={14} className="text-neutral-300" />}
        {active && sortDirection === "asc" && <ChevronUp size={14} className="text-blue-600" />}
        {active && sortDirection === "desc" && <ChevronDown size={14} className="text-blue-600" />}
      </button>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-xl font-semibold tracking-tight text-neutral-900">Student Management</h1>
        </div>

        {/* Cards are intentionally non-clickable and have no bottom accent lines. */}
        <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <SummaryCard
            title="Total Students"
            value={students.length}
            icon={<UsersRound size={20} />}
            tone="blue"
          />
          <SummaryCard
            title="Active Students"
            value={activeStudents}
            icon={<UserRoundCheck size={20} />}
            tone="green"
          />
          <SummaryCard
            title="Completed Students"
            value={completedStudents}
            icon={<GraduationCap size={20} />}
            tone="blue"
          />
          <SummaryCard
            title="Dropped Students"
            value={droppedStudents}
            icon={<UserRoundX size={20} />}
            tone="red"
          />
        </div>

        <section>
          <div className="mb-3 flex flex-col gap-3 xl:flex-row xl:items-center">
            <h2 className="shrink-0 text-lg font-semibold text-neutral-900">
              Students <span className="font-normal text-neutral-400">({filteredStudents.length})</span>
            </h2>

            <div className="relative w-full max-w-[480px] xl:ml-4">
              <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400" />
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search student..."
                className="h-12 w-full rounded-lg border border-neutral-200 bg-white pl-11 pr-4 text-sm outline-none transition placeholder:text-neutral-400 focus:border-blue-300 focus:ring-2 focus:ring-blue-50"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) => setStatusFilter(event.target.value as "All" | StudentStatus)}
              className="h-12 rounded-lg border border-neutral-200 bg-white px-4 text-sm outline-none focus:border-blue-300"
            >
              <option value="All">All Status</option>
              <option value="Active">Active</option>
              <option value="Completed">Completed</option>
              <option value="Dropped">Dropped</option>
            </select>

            <select
              value={courseFilter}
              onChange={(event) => setCourseFilter(event.target.value)}
              className="h-12 min-w-[210px] rounded-lg border border-neutral-200 bg-white px-4 text-sm outline-none focus:border-blue-300"
            >
              <option value="All">All Courses</option>
              {courseOptions.map((course) => (
                <option key={course}>{course}</option>
              ))}
            </select>

            <select
              value={feeFilter}
              onChange={(event) => setFeeFilter(event.target.value as "All" | FeeStatus)}
              className="h-12 rounded-lg border border-neutral-200 bg-white px-4 text-sm outline-none focus:border-blue-300"
            >
              <option value="All">All Fees</option>
              <option value="Fully Paid">Fully Paid</option>
              <option value="Fee Due">Fee Due</option>
              <option value="Overdue">Overdue</option>
            </select>

            <button
              type="button"
              onClick={handleDownloadExcel}
              className="xl:ml-auto inline-flex h-12 items-center justify-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-5 text-sm font-medium text-blue-700 transition hover:bg-blue-100"
            >
              <Download size={17} />
              Excel
            </button>
          </div>

          <div className="overflow-hidden rounded-xl border border-neutral-200 bg-white">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1500px] text-left text-sm">
                <thead className="border-b border-neutral-200 bg-neutral-50/80">
                  <tr>
                    <th className="px-4 py-4"><SortHeader label="Admission ID" column="admissionId" /></th>
                    <th className="px-4 py-4"><SortHeader label="Student Name" column="studentName" /></th>
                    <th className="px-4 py-4"><SortHeader label="Contact No" column="contactNo" /></th>
                    <th className="px-4 py-4"><SortHeader label="Course" column="course" /></th>
                    <th className="px-4 py-4"><SortHeader label="Admission Date" column="admissionDate" /></th>
                    <th className="px-4 py-4"><SortHeader label="End Date" column="endDate" /></th>
                    <th className="px-4 py-4"><SortHeader label="Status" column="studentStatus" /></th>
                    <th className="px-4 py-4"><SortHeader label="Fee Status" column="feeStatus" /></th>
                    <th className="px-4 py-4"><SortHeader label="HO Certificate" column="hoCertificateStatus" /></th>
                    <th className="px-4 py-4"><SortHeader label="Branch Certificate" column="branchCertificateStatus" /></th>
                    <th className="w-[60px] px-3 py-4" aria-label="Row actions" />
                  </tr>
                </thead>
                <tbody>
                  {filteredStudents.map((student) => (
                    <tr
                      key={student.admissionId}
                      onContextMenu={(event) => handleRightClick(event, student)}
                      className="border-b border-neutral-100 last:border-0 hover:bg-blue-50/30"
                    >
                      <td className="whitespace-nowrap px-4 py-4 font-medium text-neutral-900">{student.admissionId}</td>
                      <td className="whitespace-nowrap px-4 py-4 font-medium text-neutral-800">{student.studentName}</td>
                      <td className="whitespace-nowrap px-4 py-4 text-neutral-600">{student.contactNo}</td>
                      <td className="px-4 py-4 text-neutral-600">{student.course}</td>
                      <td className="whitespace-nowrap px-4 py-4 text-neutral-600">{formatDate(student.admissionDate)}</td>
                      <td className="whitespace-nowrap px-4 py-4 text-neutral-600">{formatDate(student.endDate)}</td>
                      <td className="px-4 py-4"><StudentStatusBadge status={student.studentStatus} /></td>
                      <td className="px-4 py-4"><FeeStatusBadge status={getFeeStatus(student)} /></td>
                      <td className="px-4 py-4"><CertificateStatusBadge status={student.hoCertificateStatus} /></td>
                      <td className="px-4 py-4"><CertificateStatusBadge status={student.branchCertificateStatus} /></td>
                      <td className="px-3 py-4 text-center">
                        <button
                          type="button"
                          onClick={(event) => handleActionButton(event, student)}
                          className="inline-flex h-8 w-8 items-center justify-center rounded-md text-neutral-400 transition hover:bg-blue-50 hover:text-blue-700"
                          aria-label={`Actions for ${student.studentName}`}
                        >
                          <EllipsisVertical size={18} />
                        </button>
                      </td>
                    </tr>
                  ))}
                  {!filteredStudents.length && (
                    <tr>
                      <td colSpan={11} className="px-4 py-12 text-center text-neutral-400">No students found.</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>

      {actionMenu && (
        <div
          ref={actionMenuRef}
          style={{ top: actionMenu.y, left: actionMenu.x }}
          className="fixed z-50 w-[230px] rounded-xl border border-neutral-200 bg-white p-1.5 shadow-xl"
        >
          <div className="border-b border-neutral-100 px-3 py-2.5">
            <p className="truncate text-sm font-semibold text-neutral-900">{actionMenu.student.studentName}</p>
            <p className="mt-0.5 text-xs text-neutral-400">{actionMenu.student.admissionId}</p>
          </div>
          <MenuButton
            icon={<Eye size={16} />}
            label="View Student"
            onClick={() => {
              setViewStudent(actionMenu.student);
              setActionMenu(null);
            }}
          />
          <MenuButton
            icon={<WalletCards size={16} />}
            label="Fee Management"
            onClick={() => {
              setFeeStudent(actionMenu.student);
              setActionMenu(null);
            }}
          />
          <div className="my-1 border-t border-neutral-100" />
          {actionMenu.student.studentStatus === "Active" && (
            <>
              <MenuButton
                icon={<CheckCircle2 size={16} />}
                label="Mark as Completed"
                tone="green"
                onClick={() => changeStatus(actionMenu.student, "Completed")}
              />
              <MenuButton
                icon={<UserRoundX size={16} />}
                label="Mark as Dropped"
                tone="red"
                onClick={() => changeStatus(actionMenu.student, "Dropped")}
              />
            </>
          )}
          {actionMenu.student.studentStatus !== "Active" && (
            <MenuButton
              icon={<RotateCcw size={16} />}
              label="Reactivate Student"
              tone="blue"
              onClick={() => changeStatus(actionMenu.student, "Active")}
            />
          )}
        </div>
      )}

      {viewStudent && (
        <ViewStudentModal
          student={viewStudent}
          onClose={() => setViewStudent(null)}
          onEdit={() => {
            setEditStudent(viewStudent);
            setViewStudent(null);
          }}
          onFees={() => {
            setFeeStudent(viewStudent);
            setViewStudent(null);
          }}
          onCertificateUpdate={(area, value) =>
            updateCertificateStatus(viewStudent, area, value)
          }
        />
      )}

      {editStudent && (
        <EditStudentModal
          student={editStudent}
          allStudents={students}
          onClose={() => setEditStudent(null)}
          onSave={(updated) => {
            replaceStudent(editStudent.admissionId, updated);
            setEditStudent(null);
            alert("Student details updated successfully.");
          }}
        />
      )}

      {feeStudent && (
        <FeeManagementModal
          student={feeStudent}
          allStudents={students}
          onClose={() => setFeeStudent(null)}
          onUpdate={(updated) => replaceStudent(feeStudent.admissionId, updated)}
        />
      )}

      <InputStyles />
    </div>
  );
}

function SummaryCard({
  title,
  value,
  icon,
  tone,
}: {
  title: string;
  value: number;
  icon: ReactNode;
  tone: "blue" | "green" | "red";
}) {
  const styles = {
    blue: { card: "border-blue-100 bg-blue-50/45", icon: "bg-blue-100/70 text-blue-700", title: "text-blue-700" },
    green: { card: "border-green-100 bg-green-50/45", icon: "bg-green-100/70 text-green-700", title: "text-green-700" },
    red: { card: "border-red-100 bg-red-50/45", icon: "bg-red-100/70 text-red-600", title: "text-red-600" },
  }[tone];
  return (
    <div className={`rounded-xl border p-5 ${styles.card}`}>
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className={`text-sm font-medium ${styles.title}`}>{title}</p>
          <p className="mt-2 text-3xl font-semibold tracking-tight text-neutral-900">{value}</p>
        </div>
        <span className={`inline-flex h-10 w-10 items-center justify-center rounded-lg ${styles.icon}`}>{icon}</span>
      </div>
    </div>
  );
}

function StudentStatusBadge({ status }: { status: StudentStatus }) {
  const cls =
    status === "Active"
      ? "border-green-200 bg-green-50 text-green-700"
      : status === "Completed"
        ? "border-blue-200 bg-blue-50 text-blue-700"
        : "border-red-200 bg-red-50 text-red-600";
  return <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${cls}`}>{status}</span>;
}

function FeeStatusBadge({ status }: { status: FeeStatus }) {
  const cls =
    status === "Fully Paid"
      ? "border-green-200 bg-green-50 text-green-700"
      : status === "Overdue"
        ? "border-red-200 bg-red-50 text-red-600"
        : "border-blue-200 bg-blue-50 text-blue-700";
  return <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${cls}`}>{status}</span>;
}

function CertificateStatusBadge({
  status,
}: {
  status: HoCertificateStatus | BranchCertificateStatus;
}) {
  const cls =
    status === "Generated" || status === "Issued"
      ? "border-green-200 bg-green-50 text-green-700"
      : status === "Pending"
        ? "border-amber-200 bg-amber-50 text-amber-700"
        : status === "Ongoing"
          ? "border-blue-200 bg-blue-50 text-blue-700"
          : "border-neutral-200 bg-neutral-50 text-neutral-500";

  return (
    <span
      className={`inline-flex whitespace-nowrap rounded-full border px-2.5 py-1 text-xs font-medium ${cls}`}
    >
      {status}
    </span>
  );
}

function MenuButton({
  icon,
  label,
  onClick,
  tone = "neutral",
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  tone?: "neutral" | "blue" | "green" | "red";
}) {
  const cls = {
    neutral: "text-neutral-700 hover:bg-neutral-50",
    blue: "text-blue-700 hover:bg-blue-50",
    green: "text-green-700 hover:bg-green-50",
    red: "text-red-600 hover:bg-red-50",
  }[tone];
  return (
    <button type="button" onClick={onClick} className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium ${cls}`}>
      {icon}
      {label}
    </button>
  );
}

function ViewStudentModal({
  student,
  onClose,
  onEdit,
  onFees,
  onCertificateUpdate,
}: {
  student: Student;
  onClose: () => void;
  onEdit: () => void;
  onFees: () => void;
  onCertificateUpdate: (
    area: "HO" | "Branch",
    value: HoCertificateStatus | BranchCertificateStatus
  ) => void;
}) {
  const paid = totalPaid(student);
  const due = balance(student);
  return (
    <Modal title="Student Details" onClose={onClose} maxWidth="max-w-5xl">
      <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h3 className="text-xl font-semibold text-neutral-900">{student.studentName}</h3>
          <p className="mt-1 text-sm text-neutral-500">{student.admissionId} • {student.course}</p>
        </div>
        <StudentStatusBadge status={student.studentStatus} />
      </div>

      <Section title="Admission Details">
        <Detail label="Admission ID" value={student.admissionId} />
        <Detail label="Admission Date" value={formatDate(student.admissionDate)} />
        <Detail label="End Date" value={formatDate(student.endDate)} />
        <Detail label="Course" value={student.course} />
        <Detail label="Qualification" value={student.qualification || "-"} />
      </Section>

      <Section title="Student Details">
        <Detail label="Name as per Aadhaar" value={student.studentName} />
        <Detail label="Date of Birth" value={formatDate(student.dob)} />
        <Detail label="Contact No" value={student.contactNo} />
        <Detail label="Email" value={student.email || "-"} />
        <Detail label="Father / Guardian" value={student.guardianName || "-"} />
        <Detail label="Guardian Contact" value={student.guardianContact || "-"} />
        <Detail label="Mother Name" value={student.motherName || "-"} />
        <Detail label="Aadhaar No" value={student.aadhaarNo || "-"} />
      </Section>

      <Section title="Certificate Status">
        <div>
          <p className="mb-1.5 text-xs text-neutral-400">HO Certificate</p>
          {student.studentStatus === "Completed" ? (
            <select
              value={student.hoCertificateStatus}
              onChange={(e) =>
                onCertificateUpdate(
                  "HO",
                  e.target.value as HoCertificateStatus
                )
              }
              className="input-style"
            >
              <option value="Pending">Pending</option>
              <option value="Generated">Generated</option>
            </select>
          ) : (
            <CertificateStatusBadge status={student.hoCertificateStatus} />
          )}
        </div>

        <div>
          <p className="mb-1.5 text-xs text-neutral-400">Branch Certificate</p>
          {student.studentStatus === "Completed" ? (
            <select
              value={student.branchCertificateStatus}
              disabled={student.hoCertificateStatus !== "Generated"}
              onChange={(e) =>
                onCertificateUpdate(
                  "Branch",
                  e.target.value as BranchCertificateStatus
                )
              }
              className="input-style disabled:cursor-not-allowed disabled:bg-neutral-50 disabled:text-neutral-400"
            >
              <option value="Pending">Pending</option>
              <option value="Issued">Issued</option>
            </select>
          ) : (
            <CertificateStatusBadge status={student.branchCertificateStatus} />
          )}
          {student.studentStatus === "Completed" &&
            student.hoCertificateStatus !== "Generated" && (
              <p className="mt-1 text-xs text-neutral-400">
                Available after HO marks the certificate Generated.
              </p>
            )}
        </div>
      </Section>

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <FeeInfo label="Total Fee" value={money(student.totalFee)} tone="blue" />
        <FeeInfo label="Total Paid" value={money(paid)} tone="green" />
        <FeeInfo label="Balance" value={money(due)} tone={due > 0 ? "red" : "green"} />
      </div>

      {student.studentStatus === "Dropped" && student.dropReason && (
        <div className="mb-6 rounded-xl border border-red-100 bg-red-50/50 p-4">
          <p className="text-xs font-medium text-red-500">Drop Reason</p>
          <p className="mt-1 text-sm text-red-700">{student.dropReason}</p>
        </div>
      )}

      <div className="flex justify-end gap-3 border-t border-neutral-100 pt-5">
        <button type="button" onClick={onEdit} className="light-blue-btn"><Pencil size={16} /> Edit Student</button>
        <button type="button" onClick={onFees} className="light-green-btn"><WalletCards size={16} /> Fee Management</button>
      </div>
    </Modal>
  );
}

function EditStudentModal({ student, allStudents, onClose, onSave }: { student: Student; allStudents: Student[]; onClose: () => void; onSave: (student: Student) => void }) {
  const [form, setForm] = useState<Student>({ ...student, installments: student.installments.map((x) => ({ ...x })), payments: [...student.payments] });
  const paid = totalPaid(student);

  function update<K extends keyof Student>(key: K, value: Student[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(event: FormEvent) {
    event.preventDefault();
    if (!form.admissionId.trim() || !form.admissionDate || !form.studentName.trim() || !form.dob || !form.contactNo || !form.guardianName.trim() || !form.aadhaarNo || !form.course || form.totalFee <= 0) {
      alert("Please fill all required fields.");
      return;
    }
    if (form.endDate && form.endDate < form.admissionDate) {
      alert("End Date cannot be before Admission Date.");
      return;
    }
    if (!/^\d{10}$/.test(form.contactNo)) {
      alert("Contact No must contain 10 digits.");
      return;
    }
    if (form.guardianContact && !/^\d{10}$/.test(form.guardianContact)) {
      alert("Guardian Contact must contain 10 digits.");
      return;
    }
    if (!/^\d{12}$/.test(form.aadhaarNo)) {
      alert("Aadhaar No must contain 12 digits.");
      return;
    }
    if (form.totalFee < paid) {
      alert(`Total Fee cannot be below the already paid amount ${money(paid)}.`);
      return;
    }
    const duplicate = allStudents.some(
      (item) => item.admissionId.toUpperCase() === form.admissionId.trim().toUpperCase() && item.admissionId !== student.admissionId
    );
    if (duplicate) {
      alert("Admission ID already exists.");
      return;
    }
    onSave({ ...form, admissionId: form.admissionId.trim().toUpperCase(), studentName: form.studentName.trim() });
  }

  return (
    <Modal title="Edit Student" onClose={onClose} maxWidth="max-w-5xl">
      <form onSubmit={submit}>
        <Section title="Admission Details">
          <Field label="Admission ID" required><input value={form.admissionId} onChange={(e) => update("admissionId", e.target.value)} className="input-style uppercase" /></Field>
          <Field label="Admission Date" required><input type="date" value={form.admissionDate} onChange={(e) => update("admissionDate", e.target.value)} className="input-style" /></Field>
          <Field label="End Date"><input type="date" min={form.admissionDate} value={form.endDate} onChange={(e) => update("endDate", e.target.value)} className="input-style" /></Field>
          <Field label="Course" required><input value={form.course} onChange={(e) => update("course", e.target.value)} className="input-style" /></Field>
          <Field label="Qualification"><input value={form.qualification} onChange={(e) => update("qualification", e.target.value)} className="input-style" /></Field>
        </Section>
        <Section title="Student Details">
          <Field label="Name as per Aadhaar" required><input value={form.studentName} onChange={(e) => update("studentName", e.target.value)} className="input-style" /></Field>
          <Field label="Date of Birth" required><input type="date" value={form.dob} onChange={(e) => update("dob", e.target.value)} className="input-style" /></Field>
          <Field label="Contact No" required><input inputMode="numeric" value={form.contactNo} onChange={(e) => update("contactNo", e.target.value.replace(/\D/g, "").slice(0, 10))} className="input-style" /></Field>
          <Field label="Email"><input type="email" value={form.email} onChange={(e) => update("email", e.target.value)} className="input-style" /></Field>
          <Field label="Father / Guardian Name" required><input value={form.guardianName} onChange={(e) => update("guardianName", e.target.value)} className="input-style" /></Field>
          <Field label="Guardian Contact"><input inputMode="numeric" value={form.guardianContact} onChange={(e) => update("guardianContact", e.target.value.replace(/\D/g, "").slice(0, 10))} className="input-style" /></Field>
          <Field label="Mother Name"><input value={form.motherName} onChange={(e) => update("motherName", e.target.value)} className="input-style" /></Field>
          <Field label="Aadhaar No" required><input inputMode="numeric" value={form.aadhaarNo} onChange={(e) => update("aadhaarNo", e.target.value.replace(/\D/g, "").slice(0, 12))} className="input-style" /></Field>
        </Section>
        <Section title="Fee Details">
          <Field label="Total Fee" required><input type="number" min={paid} value={form.totalFee} onChange={(e) => update("totalFee", Number(e.target.value) || 0)} className="input-style" /></Field>
          <Field label="Paid (system controlled)"><input value={money(paid)} disabled className="input-style bg-neutral-50 text-neutral-500" /></Field>
          <Field label="Balance (system controlled)"><input value={money(Math.max(0, form.totalFee - paid))} disabled className="input-style bg-neutral-50 text-neutral-500" /></Field>
        </Section>
        <div className="flex justify-end gap-3 border-t border-neutral-100 pt-5">
          <SecondaryButton onClick={onClose}>Cancel</SecondaryButton>
          <button type="submit" className="light-blue-btn"><Pencil size={16} /> Save Changes</button>
        </div>
      </form>
    </Modal>
  );
}

function FeeManagementModal({ student, allStudents, onClose, onUpdate }: { student: Student; allStudents: Student[]; onClose: () => void; onUpdate: (student: Student) => void }) {
  const [working, setWorking] = useState<Student>({ ...student, installments: student.installments.map((x) => ({ ...x })), payments: student.payments.map((x) => ({ ...x })) });
  const due = balance(working);
  const paid = totalPaid(working);
  const dueItem = nextDue(working);
  const lastPayment = [...working.payments].sort((a, b) => b.date.localeCompare(a.date))[0];
  const [paymentDate, setPaymentDate] = useState(getLocalDate());
  const [amount, setAmount] = useState(dueItem ? Math.max(0, dueItem.amount - dueItem.paidAmount) : due);
  const [mode, setMode] = useState<"Cash" | "UPI">("Cash");
  const [reference, setReference] = useState("");

  function installmentState(item: Installment) {
    if (item.paidAmount >= item.amount) return "Paid";
    if (item.paidAmount > 0) return "Partially Paid";
    if (item.date && item.date < getLocalDate()) return "Overdue";
    return "Pending";
  }

  function recordPayment() {
    if (due <= 0) {
      alert("This student has no fee balance.");
      return;
    }
    if (!paymentDate || paymentDate > getLocalDate() || paymentDate < working.admissionDate) {
      alert("Payment date must be between the admission date and today.");
      return;
    }
    if (amount <= 0 || amount > due) {
      alert(`Payment amount must be between ₹1 and ${money(due)}.`);
      return;
    }
    if (mode === "UPI" && !reference.trim()) {
      alert("UPI acknowledgement / reference number is required.");
      return;
    }
    if (mode === "UPI") {
      const duplicate = allStudents.some((s) =>
        s.payments.some((p) => p.mode === "UPI" && p.reference?.trim().toLowerCase() === reference.trim().toLowerCase())
      );
      if (duplicate) {
        alert("This UPI reference number is already used.");
        return;
      }
    }

    let remaining = amount;
    const allocated = working.installments.map((item) => {
      if (remaining <= 0) return item;
      const installmentBalance = Math.max(0, item.amount - item.paidAmount);
      const applied = Math.min(installmentBalance, remaining);
      remaining -= applied;
      return { ...item, paidAmount: item.paidAmount + applied };
    });
    const payment: Payment = {
      id: uniquePaymentId(),
      receiptNo: nextReceiptNo(allStudents),
      date: paymentDate,
      amount,
      mode,
      reference: mode === "UPI" ? reference.trim() : undefined,
    };
    const updated = { ...working, installments: allocated, payments: [...working.payments, payment] };
    setWorking(updated);
    onUpdate(updated);
    setReference("");
    const next = nextDue(updated);
    setAmount(next ? Math.max(0, next.amount - next.paidAmount) : balance(updated));
    alert(`Payment recorded successfully. Receipt: ${payment.receiptNo}`);
  }

  return (
    <Modal title="Fee Management" onClose={onClose} maxWidth="max-w-6xl">
      <div className="mb-6">
        <h3 className="text-xl font-semibold text-neutral-900">{working.studentName}</h3>
        <p className="mt-1 text-sm text-neutral-500">{working.admissionId} • {working.course}</p>
      </div>

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <FeeInfo label="Total Fee" value={money(working.totalFee)} tone="blue" />
        <FeeInfo label="Total Paid" value={money(paid)} tone="green" />
        <FeeInfo label="Balance" value={money(due)} tone={due > 0 ? "red" : "green"} />
        <FeeInfo label="Next Due" value={dueItem ? `${money(Math.max(0, dueItem.amount - dueItem.paidAmount))} • ${formatDate(dueItem.date)}` : "No Due"} tone={dueItem ? "blue" : "green"} />
      </div>

      {lastPayment && <p className="mb-6 text-sm text-neutral-500">Last Payment: <span className="font-medium text-neutral-700">{money(lastPayment.amount)} on {formatDate(lastPayment.date)}</span></p>}

      <h4 className="mb-3 font-semibold text-neutral-900">Installment Schedule</h4>
      <div className="mb-7 overflow-hidden rounded-xl border border-neutral-200">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-sm">
            <thead className="bg-neutral-50/80 text-left">
              <tr><th className="px-4 py-3">#</th><th className="px-4 py-3">Commit</th><th className="px-4 py-3">Due Date</th><th className="px-4 py-3">Paid</th><th className="px-4 py-3">Balance</th><th className="px-4 py-3">Status</th></tr>
            </thead>
            <tbody>
              {working.installments.map((item, index) => {
                const state = installmentState(item);
                return <tr key={`${item.date}-${index}`} className="border-t border-neutral-100"><td className="px-4 py-3">{index + 1}</td><td className="px-4 py-3">{money(item.amount)}</td><td className="px-4 py-3">{formatDate(item.date)}</td><td className="px-4 py-3">{money(item.paidAmount)}</td><td className="px-4 py-3">{money(item.amount - item.paidAmount)}</td><td className="px-4 py-3"><InstallmentBadge status={state} /></td></tr>;
              })}
              {!working.installments.length && <tr><td colSpan={6} className="px-4 py-8 text-center text-neutral-400">No installment schedule.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mb-7 rounded-xl border border-blue-100 bg-blue-50/30 p-5">
        <h4 className="mb-4 flex items-center gap-2 font-semibold text-neutral-900"><CircleDollarSign size={18} className="text-blue-600" /> Record Payment</h4>
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Field label="Payment Date" required><input type="date" min={working.admissionDate} max={getLocalDate()} value={paymentDate} onChange={(e) => setPaymentDate(e.target.value)} className="input-style" /></Field>
          <Field label="Amount" required><input type="number" min="1" max={due} value={amount || ""} onChange={(e) => setAmount(Number(e.target.value) || 0)} className="input-style" /></Field>
          <Field label="Payment Mode" required><select value={mode} onChange={(e) => setMode(e.target.value as "Cash" | "UPI")} className="input-style"><option value="Cash">Cash</option><option value="UPI">UPI</option></select></Field>
          {mode === "UPI" ? <Field label="UPI Reference" required><input value={reference} onChange={(e) => setReference(e.target.value)} className="input-style" /></Field> : <Field label="Balance After"><input value={money(Math.max(0, due - amount))} disabled className="input-style bg-white/70 text-neutral-500" /></Field>}
        </div>
        {mode === "UPI" && <div className="mt-4 max-w-sm"><Field label="Balance After"><input value={money(Math.max(0, due - amount))} disabled className="input-style bg-white/70 text-neutral-500" /></Field></div>}
        <div className="mt-4 flex justify-end"><button type="button" onClick={recordPayment} disabled={due <= 0} className="light-green-btn disabled:cursor-not-allowed disabled:opacity-40"><Banknote size={16} /> Record Payment</button></div>
      </div>

      <h4 className="mb-3 font-semibold text-neutral-900">Payment History</h4>
      <div className="overflow-hidden rounded-xl border border-neutral-200">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[700px] text-sm">
            <thead className="bg-neutral-50/80 text-left"><tr><th className="px-4 py-3">Receipt</th><th className="px-4 py-3">Date</th><th className="px-4 py-3">Amount</th><th className="px-4 py-3">Mode</th><th className="px-4 py-3">Reference</th></tr></thead>
            <tbody>
              {[...working.payments].reverse().map((payment) => <tr key={payment.id} className="border-t border-neutral-100"><td className="px-4 py-3 font-medium">{payment.receiptNo}</td><td className="px-4 py-3">{formatDate(payment.date)}</td><td className="px-4 py-3 font-medium text-green-700">{money(payment.amount)}</td><td className="px-4 py-3">{payment.mode}</td><td className="px-4 py-3">{payment.reference || "-"}</td></tr>)}
              {!working.payments.length && <tr><td colSpan={5} className="px-4 py-8 text-center text-neutral-400">No payment history.</td></tr>}
            </tbody>
          </table>
        </div>
      </div>
    </Modal>
  );
}

function InstallmentBadge({ status }: { status: "Paid" | "Partially Paid" | "Pending" | "Overdue" }) {
  const cls = status === "Paid" ? "border-green-200 bg-green-50 text-green-700" : status === "Overdue" ? "border-red-200 bg-red-50 text-red-600" : "border-blue-200 bg-blue-50 text-blue-700";
  return <span className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${cls}`}>{status}</span>;
}

function FeeInfo({ label, value, tone }: { label: string; value: string; tone: "blue" | "green" | "red" }) {
  const cls = tone === "green" ? "border-green-100 bg-green-50/45" : tone === "red" ? "border-red-100 bg-red-50/45" : "border-blue-100 bg-blue-50/45";
  return <div className={`rounded-xl border p-4 ${cls}`}><p className="text-xs text-neutral-500">{label}</p><p className="mt-1 text-base font-semibold text-neutral-900">{value}</p></div>;
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return <section className="mb-6"><h4 className="mb-3 font-semibold text-neutral-900">{title}</h4><div className="grid grid-cols-1 gap-4 rounded-xl border border-neutral-200 bg-white p-4 sm:grid-cols-2 lg:grid-cols-4">{children}</div></section>;
}

function Detail({ label, value }: { label: string; value: string }) {
  return <div><p className="text-xs text-neutral-400">{label}</p><p className="mt-1 text-sm font-medium text-neutral-800">{value}</p></div>;
}

function Field({ label, required, children }: { label: string; required?: boolean; children: ReactNode }) {
  return <label className="block"><div className="mb-1.5 text-sm font-medium text-neutral-700">{label}{required && <span className="ml-1 text-red-500">*</span>}</div>{children}</label>;
}

function SecondaryButton({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return <button type="button" onClick={onClick} className="inline-flex h-10 items-center justify-center gap-2 rounded-lg border border-neutral-200 bg-white px-4 text-sm font-medium text-neutral-600 transition hover:bg-neutral-50">{children}</button>;
}

function Modal({ title, children, onClose, maxWidth = "max-w-2xl" }: { title: string; children: ReactNode; onClose: () => void; maxWidth?: string }) {
  return <div className="fixed inset-0 z-[60] flex items-center justify-center bg-neutral-900/20 px-4 py-6"><div className={`max-h-[92vh] w-full ${maxWidth} overflow-y-auto rounded-2xl border border-neutral-200 bg-white shadow-2xl`}><div className="sticky top-0 z-20 flex items-center justify-between border-b border-neutral-100 bg-white/95 px-5 py-4 backdrop-blur"><h3 className="text-lg font-semibold text-neutral-900">{title}</h3><button type="button" onClick={onClose} className="rounded-lg p-2 text-neutral-400 transition hover:bg-red-50 hover:text-red-600"><X size={18} /></button></div><div className="p-5">{children}</div></div></div>;
}

function InputStyles() {
  return <style jsx global>{`
    .input-style { height: 42px; width: 100%; border-radius: 8px; border: 1px solid rgb(229 229 229); background: white; padding: 0 12px; font-size: 14px; color: rgb(38 38 38); outline: none; transition: border-color .15s ease, box-shadow .15s ease; }
    .input-style:focus { border-color: rgb(147 197 253); box-shadow: 0 0 0 3px rgb(239 246 255); }
    .input-style::placeholder { color: rgb(163 163 163); }
    .light-blue-btn { display: inline-flex; height: 40px; align-items: center; justify-content: center; gap: 8px; border-radius: 8px; border: 1px solid rgb(191 219 254); background: rgb(239 246 255); padding: 0 16px; font-size: 14px; font-weight: 500; color: rgb(29 78 216); transition: background .15s ease; }
    .light-blue-btn:hover { background: rgb(219 234 254); }
    .light-green-btn { display: inline-flex; height: 40px; align-items: center; justify-content: center; gap: 8px; border-radius: 8px; border: 1px solid rgb(187 247 208); background: rgb(240 253 244); padding: 0 16px; font-size: 14px; font-weight: 500; color: rgb(21 128 61); transition: background .15s ease; }
    .light-green-btn:hover { background: rgb(220 252 231); }
  `}</style>;
}
