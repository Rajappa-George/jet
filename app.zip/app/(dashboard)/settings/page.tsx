"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import {
  Building2,
  GitBranch,
  GraduationCap,
  UsersRound,
  Target,
  Save,
  Plus,
  MoreVertical,
  Search,
  Pencil,
  Power,
  PowerOff,
} from "lucide-react";

type ActiveStatus = "Active" | "Inactive";

type Branch = {
  code: string;
  name: string;
  contact: string;
  address: string;
  status: ActiveStatus;
};

type Course = {
  code: string;
  name: string;
  duration: string;
  defaultFee: number;
  status: ActiveStatus;
};

type UserRole =
  | "Super Admin"
  | "Admin / Management"
  | "Branch Manager"
  | "Staff";

type SystemUser = {
  name: string;
  email: string;
  role: UserRole;
  branch: string;
  status: ActiveStatus;
};

type MonthlyTarget = {
  branch: string;
  businessTarget: number;
  feeTarget: number;
};

const sampleBranches: Branch[] = [
  { code: "ARY", name: "Ariyalur", contact: "9876543210", address: "Ariyalur, Tamil Nadu", status: "Active" },
  { code: "GUV", name: "Guduvancherry", contact: "9876543211", address: "Guduvancherry, Tamil Nadu", status: "Active" },
  { code: "MYL", name: "Mayiladuthurai", contact: "9876543212", address: "Mayiladuthurai, Tamil Nadu", status: "Active" },
  { code: "PMB", name: "Perambalur", contact: "9876543213", address: "Perambalur, Tamil Nadu", status: "Active" },
  { code: "TNJ", name: "Thanjavur", contact: "9876543214", address: "Thanjavur, Tamil Nadu", status: "Active" },
  { code: "TRY", name: "Tiruchirappalli", contact: "9876543215", address: "Tiruchirappalli, Tamil Nadu", status: "Active" },
];

const sampleCourses: Course[] = [
  { code: "GER-B2", name: "German B2", duration: "6 Months", defaultFee: 35000, status: "Active" },
  { code: "FS001", name: "Full Stack Development", duration: "6 Months", defaultFee: 40000, status: "Active" },
  { code: "PY001", name: "Python Programming", duration: "4 Months", defaultFee: 25000, status: "Active" },
  { code: "BEA001", name: "Beautician", duration: "4 Months", defaultFee: 20000, status: "Active" },
];

const sampleUsers: SystemUser[] = [
  {
    name: "Admin",
    email: "admin@jetmis.in",
    role: "Super Admin",
    branch: "All Branches",
    status: "Active",
  },
  {
    name: "Rajappa George",
    email: "rajappa@jetmis.in",
    role: "Branch Manager",
    branch: "Tiruchirappalli",
    status: "Active",
  },
];

const sampleTargets: MonthlyTarget[] = [
  { branch: "Ariyalur", businessTarget: 500000, feeTarget: 300000 },
  { branch: "Guduvancherry", businessTarget: 700000, feeTarget: 400000 },
  { branch: "Mayiladuthurai", businessTarget: 500000, feeTarget: 300000 },
  { branch: "Perambalur", businessTarget: 500000, feeTarget: 300000 },
  { branch: "Thanjavur", businessTarget: 700000, feeTarget: 400000 },
  { branch: "Tiruchirappalli", businessTarget: 1000000, feeTarget: 600000 },
];

export default function SettingsPage() {
  const searchParams = useSearchParams();
  const tab = searchParams.get("tab") || "institute";

  return (
    <div className="min-h-screen bg-white p-6">
      <div className="mb-6">
        <h1 className="text-xl font-semibold tracking-tight text-neutral-900">
          Settings
        </h1>
      </div>

      {tab === "institute" && <InstituteSettings />}
      {tab === "branches" && <BranchSettings />}
      {tab === "courses" && <CourseSettings />}
      {tab === "users" && <UserSettings />}
      {tab === "targets" && <MonthlyTargetSettings />}

      {!["institute", "branches", "courses", "users", "targets"].includes(tab) && (
        <InstituteSettings />
      )}
    </div>
  );
}

function InstituteSettings() {
  const [form, setForm] = useState({
    instituteName: "JEYRAM Educational Trust (JET)",
    instituteCode: "JET",
    phone: "",
    email: "",
    website: "https://jeyedu.co.in/",
    address: "",
  });

  function updateField(field: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  function save() {
    localStorage.setItem("jet-mis-institute", JSON.stringify(form));
    alert("Institute settings saved.");
  }

  return (
    <SectionCard
      title="Institute"
      description="Manage institute details used across reports, receipts and certificates."
    >
      <div className="grid gap-5 md:grid-cols-2">
        <Field label="Institute Name" required>
          <input
            value={form.instituteName}
            onChange={(e) => updateField("instituteName", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="Institute Code">
          <input
            value={form.instituteCode}
            onChange={(e) => updateField("instituteCode", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="Phone">
          <input
            value={form.phone}
            onChange={(e) => updateField("phone", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="Email">
          <input
            type="email"
            value={form.email}
            onChange={(e) => updateField("email", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="Website">
          <input
            value={form.website}
            onChange={(e) => updateField("website", e.target.value)}
            className={inputClass}
          />
        </Field>

        <div className="md:col-span-2">
          <Field label="Address">
            <textarea
              rows={4}
              value={form.address}
              onChange={(e) => updateField("address", e.target.value)}
              className={`${inputClass} h-auto resize-none py-2.5`}
            />
          </Field>
        </div>
      </div>

      <div className="mt-6 flex justify-end border-t border-neutral-200 pt-5">
        <button type="button" onClick={save} className={primaryButtonClass}>
          <Save size={16} />
          Save Changes
        </button>
      </div>
    </SectionCard>
  );
}

function BranchSettings() {
  const [branches, setBranches] = useState(sampleBranches);
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();

    return branches.filter(
      (item) =>
        !q ||
        item.code.toLowerCase().includes(q) ||
        item.name.toLowerCase().includes(q) ||
        item.contact.includes(q)
    );
  }, [branches, search]);

  function toggleStatus(code: string) {
    setBranches((current) =>
      current.map((item) =>
        item.code === code
          ? {
              ...item,
              status: item.status === "Active" ? "Inactive" : "Active",
            }
          : item
      )
    );
  }

  return (
    <SectionCard
      title="Branches"
      description="Manage branch master data used throughout the MIS."
      action={
        <button type="button" className={primaryButtonClass}>
          <Plus size={16} />
          Add Branch
        </button>
      }
    >
      <SearchBox
        value={search}
        onChange={setSearch}
        placeholder="Search branch..."
      />

      <div className="overflow-hidden rounded-lg border border-neutral-200">
        <table className="w-full table-fixed">
          <thead className="bg-neutral-50">
            <tr>
              <Th className="w-[14%]">Code</Th>
              <Th className="w-[24%]">Branch Name</Th>
              <Th className="w-[18%]">Contact</Th>
              <Th>Address</Th>
              <Th className="w-[12%]">Status</Th>
              <Th className="w-[52px]"></Th>
            </tr>
          </thead>

          <tbody>
            {filtered.map((branch) => (
              <tr
                key={branch.code}
                className="border-t border-neutral-100 hover:bg-blue-50/30"
              >
                <Td>{branch.code}</Td>
                <Td strong>{branch.name}</Td>
                <Td>{branch.contact}</Td>
                <Td>{branch.address}</Td>
                <Td>
                  <StatusBadge status={branch.status} />
                </Td>
                <Td>
                  <ActionMenu
                    active={branch.status === "Active"}
                    onToggle={() => toggleStatus(branch.code)}
                  />
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SectionCard>
  );
}

function CourseSettings() {
  const [courses, setCourses] = useState(sampleCourses);
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();

    return courses.filter(
      (item) =>
        !q ||
        item.code.toLowerCase().includes(q) ||
        item.name.toLowerCase().includes(q)
    );
  }, [courses, search]);

  function toggleStatus(code: string) {
    setCourses((current) =>
      current.map((item) =>
        item.code === code
          ? {
              ...item,
              status: item.status === "Active" ? "Inactive" : "Active",
            }
          : item
      )
    );
  }

  return (
    <SectionCard
      title="Courses"
      description="Maintain the course master used in enquiries, admissions, students and batches."
      action={
        <button type="button" className={primaryButtonClass}>
          <Plus size={16} />
          Add Course
        </button>
      }
    >
      <SearchBox
        value={search}
        onChange={setSearch}
        placeholder="Search course..."
      />

      <div className="overflow-hidden rounded-lg border border-neutral-200">
        <table className="w-full table-fixed">
          <thead className="bg-neutral-50">
            <tr>
              <Th className="w-[15%]">Code</Th>
              <Th>Course</Th>
              <Th className="w-[18%]">Duration</Th>
              <Th className="w-[18%]">Default Fee</Th>
              <Th className="w-[12%]">Status</Th>
              <Th className="w-[52px]"></Th>
            </tr>
          </thead>

          <tbody>
            {filtered.map((course) => (
              <tr
                key={course.code}
                className="border-t border-neutral-100 hover:bg-blue-50/30"
              >
                <Td>{course.code}</Td>
                <Td strong>{course.name}</Td>
                <Td>{course.duration}</Td>
                <Td>{formatCurrency(course.defaultFee)}</Td>
                <Td>
                  <StatusBadge status={course.status} />
                </Td>
                <Td>
                  <ActionMenu
                    active={course.status === "Active"}
                    onToggle={() => toggleStatus(course.code)}
                  />
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SectionCard>
  );
}

function UserSettings() {
  const [users, setUsers] = useState(sampleUsers);

  function toggleStatus(email: string) {
    setUsers((current) =>
      current.map((item) =>
        item.email === email
          ? {
              ...item,
              status: item.status === "Active" ? "Inactive" : "Active",
            }
          : item
      )
    );
  }

  return (
    <SectionCard
      title="Users & Roles"
      description="Manage MIS login users, roles, branch access and account status."
      action={
        <button type="button" className={primaryButtonClass}>
          <Plus size={16} />
          Add User
        </button>
      }
    >
      <div className="overflow-hidden rounded-lg border border-neutral-200">
        <table className="w-full table-fixed">
          <thead className="bg-neutral-50">
            <tr>
              <Th className="w-[20%]">Name</Th>
              <Th className="w-[25%]">Email</Th>
              <Th className="w-[20%]">Role</Th>
              <Th>Branch</Th>
              <Th className="w-[12%]">Status</Th>
              <Th className="w-[52px]"></Th>
            </tr>
          </thead>

          <tbody>
            {users.map((user) => (
              <tr
                key={user.email}
                className="border-t border-neutral-100 hover:bg-blue-50/30"
              >
                <Td strong>{user.name}</Td>
                <Td>{user.email}</Td>
                <Td>{user.role}</Td>
                <Td>{user.branch}</Td>
                <Td>
                  <StatusBadge status={user.status} />
                </Td>
                <Td>
                  <ActionMenu
                    active={user.status === "Active"}
                    onToggle={() => toggleStatus(user.email)}
                  />
                </Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SectionCard>
  );
}

function MonthlyTargetSettings() {
  const [month, setMonth] = useState("2026-09");
  const [targets, setTargets] = useState(sampleTargets);

  function updateTarget(
    branch: string,
    field: "businessTarget" | "feeTarget",
    value: string
  ) {
    const amount = Math.max(0, Number(value) || 0);

    setTargets((current) =>
      current.map((item) =>
        item.branch === branch ? { ...item, [field]: amount } : item
      )
    );
  }

  function saveTargets() {
    localStorage.setItem(
      `jet-mis-monthly-targets-${month}`,
      JSON.stringify(targets)
    );
    alert("Monthly targets saved.");
  }

  const businessTotal = targets.reduce(
    (sum, item) => sum + item.businessTarget,
    0
  );

  const feeTotal = targets.reduce(
    (sum, item) => sum + item.feeTarget,
    0
  );

  return (
    <SectionCard
      title="Monthly Targets"
      description="Set business and fee collection targets by branch and month."
    >
      <div className="mb-5 max-w-xs">
        <Field label="Month" required>
          <input
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            className={inputClass}
          />
        </Field>
      </div>

      <div className="overflow-hidden rounded-lg border border-neutral-200">
        <table className="w-full">
          <thead className="bg-neutral-50">
            <tr>
              <Th>Branch</Th>
              <Th className="w-[30%]">Business Target</Th>
              <Th className="w-[30%]">Fee Collection Target</Th>
            </tr>
          </thead>

          <tbody>
            {targets.map((target) => (
              <tr
                key={target.branch}
                className="border-t border-neutral-100"
              >
                <Td strong>{target.branch}</Td>
                <Td>
                  <MoneyInput
                    value={target.businessTarget}
                    onChange={(value) =>
                      updateTarget(target.branch, "businessTarget", value)
                    }
                  />
                </Td>
                <Td>
                  <MoneyInput
                    value={target.feeTarget}
                    onChange={(value) =>
                      updateTarget(target.branch, "feeTarget", value)
                    }
                  />
                </Td>
              </tr>
            ))}

            <tr className="border-t border-neutral-200 bg-neutral-50/70">
              <Td strong>Total</Td>
              <Td strong>{formatCurrency(businessTotal)}</Td>
              <Td strong>{formatCurrency(feeTotal)}</Td>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex justify-end border-t border-neutral-200 pt-5">
        <button
          type="button"
          onClick={saveTargets}
          className={primaryButtonClass}
        >
          <Save size={16} />
          Save Targets
        </button>
      </div>
    </SectionCard>
  );
}

function SectionCard({
  title,
  description,
  action,
  children,
}: {
  title: string;
  description: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-xl border border-neutral-200 bg-white">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-neutral-200 px-5 py-4">
        <div>
          <h2 className="font-semibold text-neutral-900">{title}</h2>
          <p className="mt-1 text-sm text-neutral-500">{description}</p>
        </div>

        {action}
      </div>

      <div className="p-5">{children}</div>
    </section>
  );
}

function Field({
  label,
  required = false,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-neutral-700">
        {label}
        {required && <span className="ml-1 text-red-500">*</span>}
      </span>
      {children}
    </label>
  );
}

function SearchBox({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
}) {
  return (
    <div className="relative mb-4 max-w-sm">
      <Search
        size={16}
        className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400"
      />
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-10 w-full rounded-lg border border-neutral-200 bg-white pl-9 pr-3 text-sm outline-none transition focus:border-blue-300 focus:ring-2 focus:ring-blue-50"
      />
    </div>
  );
}

function MoneyInput({
  value,
  onChange,
}: {
  value: number;
  onChange: (value: string) => void;
}) {
  return (
    <div className="relative max-w-xs">
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-neutral-400">
        ₹
      </span>
      <input
        type="number"
        min="0"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`${inputClass} pl-7`}
      />
    </div>
  );
}

function StatusBadge({ status }: { status: ActiveStatus }) {
  return (
    <span
      className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
        status === "Active"
          ? "border-green-200 bg-green-50 text-green-700"
          : "border-neutral-200 bg-neutral-50 text-neutral-600"
      }`}
    >
      {status}
    </span>
  );
}

function ActionMenu({
  active,
  onToggle,
}: {
  active: boolean;
  onToggle: () => void;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex h-8 w-8 items-center justify-center rounded-md text-neutral-500 hover:bg-neutral-100"
      >
        <MoreVertical size={17} />
      </button>

      {open && (
        <div className="absolute right-0 top-9 z-30 w-44 rounded-lg border border-neutral-200 bg-white p-1.5 shadow-lg">
          <button
            type="button"
            className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm text-neutral-700 hover:bg-neutral-50"
          >
            <Pencil size={15} />
            Edit
          </button>

          <button
            type="button"
            onClick={() => {
              onToggle();
              setOpen(false);
            }}
            className={`flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm ${
              active
                ? "text-red-600 hover:bg-red-50"
                : "text-green-700 hover:bg-green-50"
            }`}
          >
            {active ? <PowerOff size={15} /> : <Power size={15} />}
            {active ? "Change to Inactive" : "Change to Active"}
          </button>
        </div>
      )}
    </div>
  );
}

function Th({
  children,
  className = "",
}: {
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <th
      className={`px-3 py-3 text-left text-xs font-semibold uppercase tracking-wide text-neutral-500 ${className}`}
    >
      {children}
    </th>
  );
}

function Td({
  children,
  strong = false,
}: {
  children: React.ReactNode;
  strong?: boolean;
}) {
  return (
    <td
      className={`whitespace-normal break-words px-3 py-3.5 text-sm ${
        strong
          ? "font-medium text-neutral-900"
          : "text-neutral-600"
      }`}
    >
      {children}
    </td>
  );
}

function formatCurrency(value: number) {
  return `₹${value.toLocaleString("en-IN")}`;
}

const inputClass =
  "h-10 w-full rounded-lg border border-neutral-200 bg-white px-3 text-sm text-neutral-800 outline-none transition placeholder:text-neutral-400 focus:border-blue-300 focus:ring-2 focus:ring-blue-50";

const primaryButtonClass =
  "inline-flex h-10 items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-4 text-sm font-medium text-blue-700 transition hover:bg-blue-100";
