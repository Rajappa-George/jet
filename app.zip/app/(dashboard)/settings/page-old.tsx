"use client";

import { useMemo, useState, type ReactNode } from "react";
import {
  Building2,
  GitBranch,
  GraduationCap,
  UsersRound,
  Target,
  Save,
  Plus,
  MoreVertical,
  Search,
  Pencil,
  Power,
  PowerOff,
} from "lucide-react";

type SettingsTab =
  | "Institute"
  | "Branches"
  | "Courses"
  | "Users & Roles"
  | "Monthly Targets";

type ActiveStatus = "Active" | "Inactive";

type Branch = {
  code: string;
  name: string;
  contact: string;
  address: string;
  status: ActiveStatus;
};

type Course = {
  code: string;
  name: string;
  duration: string;
  defaultFee: number;
  status: ActiveStatus;
};

type UserRole =
  | "Super Admin"
  | "Admin / Management"
  | "Branch Manager"
  | "Staff";

type SystemUser = {
  name: string;
  email: string;
  role: UserRole;
  branch: string;
  status: ActiveStatus;
};

type MonthlyTarget = {
  branch: string;
  businessTarget: number;
  feeTarget: number;
};

const settingsTabs: {
  label: SettingsTab;
  icon: ReactNode;
}[] = [
  { label: "Institute", icon: <Building2 size={18} /> },
  { label: "Branches", icon: <GitBranch size={18} /> },
  { label: "Courses", icon: <GraduationCap size={18} /> },
  { label: "Users & Roles", icon: <UsersRound size={18} /> },
  { label: "Monthly Targets", icon: <Target size={18} /> },
];

const sampleBranches: Branch[] = [
  {
    code: "ARY",
    name: "Ariyalur",
    contact: "9876543210",
    address: "Ariyalur, Tamil Nadu",
    status: "Active",
  },
  {
    code: "GUV",
    name: "Guduvancherry",
    contact: "9876543211",
    address: "Guduvancherry, Tamil Nadu",
    status: "Active",
  },
  {
    code: "MYL",
    name: "Mayiladuthurai",
    contact: "9876543212",
    address: "Mayiladuthurai, Tamil Nadu",
    status: "Active",
  },
  {
    code: "PMB",
    name: "Perambalur",
    contact: "9876543213",
    address: "Perambalur, Tamil Nadu",
    status: "Active",
  },
  {
    code: "TNJ",
    name: "Thanjavur",
    contact: "9876543214",
    address: "Thanjavur, Tamil Nadu",
    status: "Active",
  },
  {
    code: "TRY",
    name: "Tiruchirappalli",
    contact: "9876543215",
    address: "Tiruchirappalli, Tamil Nadu",
    status: "Active",
  },
];

const sampleCourses: Course[] = [
  {
    code: "GER-B2",
    name: "German B2",
    duration: "6 Months",
    defaultFee: 35000,
    status: "Active",
  },
  {
    code: "FS001",
    name: "Full Stack Development",
    duration: "6 Months",
    defaultFee: 40000,
    status: "Active",
  },
  {
    code: "PY001",
    name: "Python Programming",
    duration: "4 Months",
    defaultFee: 25000,
    status: "Active",
  },
  {
    code: "BEA001",
    name: "Beautician",
    duration: "4 Months",
    defaultFee: 20000,
    status: "Active",
  },
];

const sampleUsers: SystemUser[] = [
  {
    name: "Admin",
    email: "admin@jetmis.in",
    role: "Super Admin",
    branch: "All Branches",
    status: "Active",
  },
  {
    name: "Rajappa George",
    email: "rajappa@jetmis.in",
    role: "Branch Manager",
    branch: "Tiruchirappalli",
    status: "Active",
  },
  {
    name: "Jagadeesan",
    email: "jagadeesan@jetmis.in",
    role: "Admin / Management",
    branch: "All Branches",
    status: "Active",
  },
];

const sampleTargets: MonthlyTarget[] = [
  { branch: "Ariyalur", businessTarget: 500000, feeTarget: 300000 },
  { branch: "Guduvancherry", businessTarget: 700000, feeTarget: 400000 },
  { branch: "Mayiladuthurai", businessTarget: 500000, feeTarget: 300000 },
  { branch: "Perambalur", businessTarget: 500000, feeTarget: 300000 },
  { branch: "Thanjavur", businessTarget: 700000, feeTarget: 400000 },
  { branch: "Tiruchirappalli", businessTarget: 1000000, feeTarget: 600000 },
];

export default function SettingsPage() {
  const [activeTab, setActiveTab] = useState<SettingsTab>("Institute");

  return (
    <div className="min-h-screen bg-white p-6">
      <div className="mb-6">
        <h1 className="text-xl font-semibold tracking-tight text-neutral-900">
          Settings
        </h1>
      </div>

      <div className="flex min-h-[620px] overflow-hidden rounded-xl border border-neutral-200 bg-white">
        {/* CHILD SETTINGS SIDEBAR */}
        <aside className="w-60 shrink-0 border-r border-neutral-200 bg-neutral-50/50 p-3">
          <div className="mb-2 px-3 py-2">
            <p className="text-xs font-semibold uppercase tracking-wider text-neutral-400">
              Settings Menu
            </p>
          </div>

          <nav className="space-y-1">
            {settingsTabs.map((tab) => {
              const isActive = activeTab === tab.label;

              return (
                <button
                  key={tab.label}
                  type="button"
                  onClick={() => setActiveTab(tab.label)}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition ${
                    isActive
                      ? "bg-blue-50 text-blue-700"
                      : "text-neutral-600 hover:bg-white hover:text-neutral-900"
                  }`}
                >
                  <span
                    className={
                      isActive ? "text-blue-600" : "text-neutral-400"
                    }
                  >
                    {tab.icon}
                  </span>

                  <span className="flex-1">{tab.label}</span>

                  {isActive && (
                    <span className="h-1.5 w-1.5 rounded-full bg-blue-500" />
                  )}
                </button>
              );
            })}
          </nav>
        </aside>

        {/* SELECTED SETTINGS CONTENT */}
        <main className="min-w-0 flex-1 bg-white p-5">
          {activeTab === "Institute" && <InstituteSettings />}
          {activeTab === "Branches" && <BranchSettings />}
          {activeTab === "Courses" && <CourseSettings />}
          {activeTab === "Users & Roles" && <UserSettings />}
          {activeTab === "Monthly Targets" && <MonthlyTargetSettings />}
        </main>
      </div>
    </div>
  );
}

function InstituteSettings() {
  const [form, setForm] = useState({
    instituteName: "JEYRAM Educational Trust (JET)",
    instituteCode: "JET",
    phone: "",
    email: "",
    website: "https://jeyedu.co.in/",
    address: "",
  });

  function updateField(field: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  function save() {
    localStorage.setItem("jet-mis-institute", JSON.stringify(form));
    alert("Institute settings saved.");
  }

  return (
    <SettingsCard
      title="Institute"
      description="Manage the institute details used across reports, receipts and certificates."
    >
      <div className="grid gap-5 md:grid-cols-2">
        <Field label="Institute Name" required>
          <input
            value={form.instituteName}
            onChange={(e) => updateField("instituteName", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="Institute Code">
          <input
            value={form.instituteCode}
            onChange={(e) => updateField("instituteCode", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="Phone">
          <input
            value={form.phone}
            onChange={(e) => updateField("phone", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="Email">
          <input
            type="email"
            value={form.email}
            onChange={(e) => updateField("email", e.target.value)}
            className={inputClass}
          />
        </Field>

        <Field label="Website">
          <input
            value={form.website}
            onChange={(e) => updateField("website", e.target.value)}
            className={inputClass}
          />
        </Field>

        <div className="md:col-span-2">
          <Field label="Address">
            <textarea
              rows={4}
              value={form.address}
              onChange={(e) => updateField("address", e.target.value)}
              className={`${inputClass} h-auto resize-none py-2.5`}
            />
          </Field>
        </div>
      </div>

      <div className="mt-6 flex justify-end border-t border-neutral-200 pt-5">
        <button
          type="button"
          onClick={save}
          className={primaryButtonClass}
        >
          <Save size={16} />
          Save Changes
        </button>
      </div>
    </SettingsCard>
  );
}

function BranchSettings() {
  const [branches, setBranches] = useState<Branch[]>(sampleBranches);
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();

    return branches.filter(
      (branch) =>
        !query ||
        branch.code.toLowerCase().includes(query) ||
        branch.name.toLowerCase().includes(query) ||
        branch.contact.includes(query)
    );
  }, [branches, search]);

  function toggleStatus(code: string) {
    setBranches((current) =>
      current.map((branch) =>
        branch.code === code
          ? {
              ...branch,
              status: branch.status === "Active" ? "Inactive" : "Active",
            }
          : branch
      )
    );
  }

  return (
    <SettingsCard
      title="Branches"
      description="Manage branch master data used throughout the MIS."
      action={
        <button type="button" className={primaryButtonClass}>
          <Plus size={16} />
          Add Branch
        </button>
      }
    >
      <ToolbarSearch
        value={search}
        onChange={setSearch}
        placeholder="Search branch..."
      />

      <div className="overflow-hidden rounded-lg border border-neutral-200">
        <table className="w-full table-fixed">
          <thead className="bg-neutral-50">
            <tr>
              <TableHead className="w-[14%]">Code</TableHead>
              <TableHead className="w-[24%]">Branch Name</TableHead>
              <TableHead className="w-[18%]">Contact</TableHead>
              <TableHead>Address</TableHead>
              <TableHead className="w-[12%]">Status</TableHead>
              <TableHead className="w-[52px]">{""}</TableHead>
            </tr>
          </thead>

          <tbody>
            {filtered.map((branch) => (
              <tr
                key={branch.code}
                className="border-t border-neutral-100 hover:bg-blue-50/30"
              >
                <TableCell>{branch.code}</TableCell>
                <TableCell strong>{branch.name}</TableCell>
                <TableCell>{branch.contact}</TableCell>
                <TableCell>{branch.address}</TableCell>
                <TableCell>
                  <StatusBadge status={branch.status} />
                </TableCell>
                <TableCell>
                  <SimpleActionMenu
                    active={branch.status === "Active"}
                    onToggle={() => toggleStatus(branch.code)}
                  />
                </TableCell>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SettingsCard>
  );
}

function CourseSettings() {
  const [courses, setCourses] = useState<Course[]>(sampleCourses);
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    const query = search.trim().toLowerCase();

    return courses.filter(
      (course) =>
        !query ||
        course.code.toLowerCase().includes(query) ||
        course.name.toLowerCase().includes(query)
    );
  }, [courses, search]);

  function toggleStatus(code: string) {
    setCourses((current) =>
      current.map((course) =>
        course.code === code
          ? {
              ...course,
              status: course.status === "Active" ? "Inactive" : "Active",
            }
          : course
      )
    );
  }

  return (
    <SettingsCard
      title="Courses"
      description="Maintain the centralized course master used in enquiries, admissions, students and batches."
      action={
        <button type="button" className={primaryButtonClass}>
          <Plus size={16} />
          Add Course
        </button>
      }
    >
      <ToolbarSearch
        value={search}
        onChange={setSearch}
        placeholder="Search course..."
      />

      <div className="overflow-hidden rounded-lg border border-neutral-200">
        <table className="w-full table-fixed">
          <thead className="bg-neutral-50">
            <tr>
              <TableHead className="w-[15%]">Code</TableHead>
              <TableHead>Course</TableHead>
              <TableHead className="w-[18%]">Duration</TableHead>
              <TableHead className="w-[18%]">Default Fee</TableHead>
              <TableHead className="w-[12%]">Status</TableHead>
              <TableHead className="w-[52px]">{""}</TableHead>
            </tr>
          </thead>

          <tbody>
            {filtered.map((course) => (
              <tr
                key={course.code}
                className="border-t border-neutral-100 hover:bg-blue-50/30"
              >
                <TableCell>{course.code}</TableCell>
                <TableCell strong>{course.name}</TableCell>
                <TableCell>{course.duration}</TableCell>
                <TableCell>{formatCurrency(course.defaultFee)}</TableCell>
                <TableCell>
                  <StatusBadge status={course.status} />
                </TableCell>
                <TableCell>
                  <SimpleActionMenu
                    active={course.status === "Active"}
                    onToggle={() => toggleStatus(course.code)}
                  />
                </TableCell>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SettingsCard>
  );
}

function UserSettings() {
  const [users, setUsers] = useState<SystemUser[]>(sampleUsers);

  function toggleUser(email: string) {
    setUsers((current) =>
      current.map((user) =>
        user.email === email
          ? {
              ...user,
              status: user.status === "Active" ? "Inactive" : "Active",
            }
          : user
      )
    );
  }

  return (
    <SettingsCard
      title="Users & Roles"
      description="Control MIS login users, roles, branch access and account status."
      action={
        <button type="button" className={primaryButtonClass}>
          <Plus size={16} />
          Add User
        </button>
      }
    >
      <div className="overflow-hidden rounded-lg border border-neutral-200">
        <table className="w-full table-fixed">
          <thead className="bg-neutral-50">
            <tr>
              <TableHead className="w-[20%]">Name</TableHead>
              <TableHead className="w-[25%]">Email</TableHead>
              <TableHead className="w-[20%]">Role</TableHead>
              <TableHead>Branch</TableHead>
              <TableHead className="w-[12%]">Status</TableHead>
              <TableHead className="w-[52px]">{""}</TableHead>
            </tr>
          </thead>

          <tbody>
            {users.map((user) => (
              <tr
                key={user.email}
                className="border-t border-neutral-100 hover:bg-blue-50/30"
              >
                <TableCell strong>{user.name}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{user.role}</TableCell>
                <TableCell>{user.branch}</TableCell>
                <TableCell>
                  <StatusBadge status={user.status} />
                </TableCell>
                <TableCell>
                  <SimpleActionMenu
                    active={user.status === "Active"}
                    onToggle={() => toggleUser(user.email)}
                  />
                </TableCell>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </SettingsCard>
  );
}

function MonthlyTargetSettings() {
  const [month, setMonth] = useState("2026-09");
  const [targets, setTargets] =
    useState<MonthlyTarget[]>(sampleTargets);

  function updateTarget(
    branch: string,
    field: "businessTarget" | "feeTarget",
    value: string
  ) {
    const amount = Math.max(0, Number(value) || 0);

    setTargets((current) =>
      current.map((target) =>
        target.branch === branch
          ? { ...target, [field]: amount }
          : target
      )
    );
  }

  function saveTargets() {
    const key = `jet-mis-monthly-targets-${month}`;

    localStorage.setItem(
      key,
      JSON.stringify(targets)
    );

    alert("Monthly targets saved.");
  }

  const businessTotal = targets.reduce(
    (sum, target) => sum + target.businessTarget,
    0
  );

  const feeTotal = targets.reduce(
    (sum, target) => sum + target.feeTarget,
    0
  );

  return (
    <SettingsCard
      title="Monthly Targets"
      description="Set business and fee collection targets by month and branch."
    >
      <div className="mb-5 max-w-xs">
        <Field label="Month" required>
          <input
            type="month"
            value={month}
            onChange={(e) => setMonth(e.target.value)}
            className={inputClass}
          />
        </Field>
      </div>

      <div className="overflow-hidden rounded-lg border border-neutral-200">
        <table className="w-full">
          <thead className="bg-neutral-50">
            <tr>
              <TableHead>Branch</TableHead>
              <TableHead className="w-[30%]">Business Target</TableHead>
              <TableHead className="w-[30%]">Fee Collection Target</TableHead>
            </tr>
          </thead>

          <tbody>
            {targets.map((target) => (
              <tr
                key={target.branch}
                className="border-t border-neutral-100"
              >
                <TableCell strong>{target.branch}</TableCell>

                <TableCell>
                  <MoneyInput
                    value={target.businessTarget}
                    onChange={(value) =>
                      updateTarget(
                        target.branch,
                        "businessTarget",
                        value
                      )
                    }
                  />
                </TableCell>

                <TableCell>
                  <MoneyInput
                    value={target.feeTarget}
                    onChange={(value) =>
                      updateTarget(
                        target.branch,
                        "feeTarget",
                        value
                      )
                    }
                  />
                </TableCell>
              </tr>
            ))}

            <tr className="border-t border-neutral-200 bg-neutral-50/70">
              <TableCell strong>Total</TableCell>
              <TableCell strong>
                {formatCurrency(businessTotal)}
              </TableCell>
              <TableCell strong>
                {formatCurrency(feeTotal)}
              </TableCell>
            </tr>
          </tbody>
        </table>
      </div>

      <div className="mt-6 flex justify-end border-t border-neutral-200 pt-5">
        <button
          type="button"
          onClick={saveTargets}
          className={primaryButtonClass}
        >
          <Save size={16} />
          Save Targets
        </button>
      </div>
    </SettingsCard>
  );
}

function SettingsCard({
  title,
  description,
  action,
  children,
}: {
  title: string;
  description: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="rounded-xl border border-neutral-200 bg-white">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-neutral-200 px-5 py-4">
        <div>
          <h2 className="font-semibold text-neutral-900">{title}</h2>
          <p className="mt-1 text-sm text-neutral-500">{description}</p>
        </div>

        {action}
      </div>

      <div className="p-5">{children}</div>
    </section>
  );
}

function Field({
  label,
  required = false,
  children,
}: {
  label: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-neutral-700">
        {label}
        {required && <span className="ml-1 text-red-500">*</span>}
      </span>

      {children}
    </label>
  );
}

function ToolbarSearch({
  value,
  onChange,
  placeholder,
}: {
  value: string;
  onChange: (value: string) => void;
  placeholder: string;
}) {
  return (
    <div className="relative mb-4 max-w-sm">
      <Search
        size={16}
        className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400"
      />

      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="h-10 w-full rounded-lg border border-neutral-200 bg-white pl-9 pr-3 text-sm outline-none transition focus:border-blue-300 focus:ring-2 focus:ring-blue-50"
      />
    </div>
  );
}

function MoneyInput({
  value,
  onChange,
}: {
  value: number;
  onChange: (value: string) => void;
}) {
  return (
    <div className="relative max-w-xs">
      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-neutral-400">
        ₹
      </span>

      <input
        type="number"
        min="0"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={`${inputClass} pl-7`}
      />
    </div>
  );
}

function StatusBadge({
  status,
}: {
  status: ActiveStatus;
}) {
  return (
    <span
      className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${
        status === "Active"
          ? "border-green-200 bg-green-50 text-green-700"
          : "border-neutral-200 bg-neutral-50 text-neutral-600"
      }`}
    >
      {status}
    </span>
  );
}

function SimpleActionMenu({
  active,
  onToggle,
}: {
  active: boolean;
  onToggle: () => void;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        className="flex h-8 w-8 items-center justify-center rounded-md text-neutral-500 transition hover:bg-neutral-100 hover:text-neutral-900"
      >
        <MoreVertical size={17} />
      </button>

      {open && (
        <div className="absolute right-0 top-9 z-20 w-44 rounded-lg border border-neutral-200 bg-white p-1.5 shadow-lg">
          <button
            type="button"
            className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm text-neutral-700 hover:bg-neutral-50"
          >
            <Pencil size={15} />
            Edit
          </button>

          <button
            type="button"
            onClick={() => {
              onToggle();
              setOpen(false);
            }}
            className={`flex w-full items-center gap-2 rounded-md px-3 py-2 text-left text-sm ${
              active
                ? "text-red-600 hover:bg-red-50"
                : "text-green-700 hover:bg-green-50"
            }`}
          >
            {active ? <PowerOff size={15} /> : <Power size={15} />}
            {active ? "Change to Inactive" : "Change to Active"}
          </button>
        </div>
      )}
    </div>
  );
}

function TableHead({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <th
      className={`px-3 py-3 text-left text-xs font-semibold uppercase tracking-wide text-neutral-500 ${className}`}
    >
      {children}
    </th>
  );
}

function TableCell({
  children,
  strong = false,
}: {
  children: ReactNode;
  strong?: boolean;
}) {
  return (
    <td
      className={`whitespace-normal break-words px-3 py-3.5 text-sm ${
        strong
          ? "font-medium text-neutral-900"
          : "text-neutral-600"
      }`}
    >
      {children}
    </td>
  );
}

function formatCurrency(value: number) {
  return `₹${value.toLocaleString("en-IN")}`;
}

const inputClass =
  "h-10 w-full rounded-lg border border-neutral-200 bg-white px-3 text-sm text-neutral-800 outline-none transition placeholder:text-neutral-400 focus:border-blue-300 focus:ring-2 focus:ring-blue-50";

const primaryButtonClass =
  "inline-flex h-10 items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-4 text-sm font-medium text-blue-700 transition hover:bg-blue-100";
