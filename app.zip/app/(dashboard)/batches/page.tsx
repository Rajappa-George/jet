"use client";

import {
  Check,
  ChevronDown,
  ChevronUp,
  Clock3,
  Download,
  Edit3,
  EllipsisVertical,
  Eye,
  GraduationCap,
  Plus,
  Search,
  Trash2,
  UserPlus,
  Users,
  X,
} from "lucide-react";
import {
  FormEvent,
  MouseEvent as ReactMouseEvent,
  ReactNode,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

type BatchStatus = "Upcoming" | "Ongoing" | "Completed";
type SortKey = "batchId" | "batchName" | "course" | "startDate" | "status";
type SortDirection = "asc" | "desc";

type TrainerMaster = {
  id: string;
  name: string;
  contact: string;
  email: string;
};

type TrainerAssignment = TrainerMaster & {
  skill: string;
};

type StudentOption = {
  id: string;
  name: string;
  contact: string;
  course: string;
};

type Batch = {
  batchId: string;
  batchName: string;
  course: string;
  startDate: string;
  endDate: string;
  startTime: string;
  endTime: string;
  maxStudents: number;
  description: string;
  students: string[];
  trainers: TrainerAssignment[];
};

type ActionMenu =
  | {
      batch: Batch;
      x: number;
      y: number;
    }
  | null;

const courseOptions = [
  "Full Stack Development",
  "Java Full Stack Development",
  "Python Programming",
  "Web Development",
  "Data Analytics",
  "UI/UX Designing",
  "Beautician",
  "Fashion Designing",
];

const sampleStudents: StudentOption[] = [
  {
    id: "TRY/AUG001",
    name: "Arun Kumar",
    contact: "9876543210",
    course: "Full Stack Development",
  },
  {
    id: "TRY/AUG002",
    name: "Priya S",
    contact: "9876543211",
    course: "Beautician",
  },
  {
    id: "TRY/AUG003",
    name: "Karthik R",
    contact: "9876543212",
    course: "Python Programming",
  },
  {
    id: "TRY/AUG004",
    name: "Deepa R",
    contact: "9876543213",
    course: "Fashion Designing",
  },
  {
    id: "TRY/AUG005",
    name: "Mohamed Irfan",
    contact: "9876543214",
    course: "UI/UX Designing",
  },
];

const defaultTrainerOptions: TrainerMaster[] = [
  {
    id: "TR001",
    name: "Raj Kumar",
    contact: "9876500001",
    email: "raj@example.com",
  },
  {
    id: "TR002",
    name: "Arun S",
    contact: "9876500002",
    email: "arun@example.com",
  },
  {
    id: "TR003",
    name: "Vignesh K",
    contact: "9876500003",
    email: "vignesh@example.com",
  },
  {
    id: "TR004",
    name: "Priya M",
    contact: "9876500004",
    email: "priya@example.com",
  },
  {
    id: "TR005",
    name: "Deepak R",
    contact: "9876500005",
    email: "deepak@example.com",
  },
];

const sampleBatches: Batch[] = [
  {
    batchId: "BAT001",
    batchName: "Full Stack Morning",
    course: "Full Stack Development",
    startDate: "2026-09-01",
    endDate: "2026-12-01",
    startTime: "09:00",
    endTime: "11:00",
    maxStudents: 25,
    description: "Morning Full Stack Development batch.",
    students: ["TRY/AUG001"],
    trainers: [
      {
        id: "TR001",
        name: "Raj Kumar",
        contact: "9876500001",
        email: "raj@example.com",
        skill: "Front-End Development",
      },
      {
        id: "TR002",
        name: "Arun S",
        contact: "9876500002",
        email: "arun@example.com",
        skill: "Back-End Development",
      },
    ],
  },
  {
    batchId: "BAT002",
    batchName: "Python Evening",
    course: "Python Programming",
    startDate: "2026-09-15",
    endDate: "2026-11-30",
    startTime: "16:00",
    endTime: "18:00",
    maxStudents: 20,
    description: "Evening Python batch.",
    students: ["TRY/AUG003"],
    trainers: [
      {
        id: "TR003",
        name: "Vignesh K",
        contact: "9876500003",
        email: "vignesh@example.com",
        skill: "Python Programming",
      },
    ],
  },
];

function getLocalDate() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDate(date: string) {
  if (!date) return "-";
  return new Date(`${date}T00:00:00`).toLocaleDateString("en-GB");
}

function formatTime(time: string) {
  if (!time) return "-";
  const [hourValue, minute] = time.split(":");
  let hour = Number(hourValue);
  const period = hour >= 12 ? "PM" : "AM";
  hour %= 12;
  if (hour === 0) hour = 12;
  return `${String(hour).padStart(2, "0")}:${minute} ${period}`;
}

function getBatchStatus(batch: Batch): BatchStatus {
  const today = getLocalDate();
  if (today < batch.startDate) return "Upcoming";
  if (today > batch.endDate) return "Completed";
  return "Ongoing";
}

export default function BatchManagementPage() {
  const [batches, setBatches] = useState<Batch[]>(sampleBatches);
  const [students, setStudents] = useState<StudentOption[]>(sampleStudents);
  const [trainerOptions, setTrainerOptions] =
    useState<TrainerMaster[]>(defaultTrainerOptions);

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"All" | BatchStatus>("All");
  const [sortKey, setSortKey] = useState<SortKey>("startDate");
  const [sortDirection, setSortDirection] = useState<SortDirection>("desc");

  const [actionMenu, setActionMenu] = useState<ActionMenu>(null);
  const actionMenuRef = useRef<HTMLDivElement | null>(null);

  const [createBatchOpen, setCreateBatchOpen] = useState(false);
  const [viewBatch, setViewBatch] = useState<Batch | null>(null);
  const [editBatch, setEditBatch] = useState<Batch | null>(null);
  const [assignmentBatch, setAssignmentBatch] = useState<Batch | null>(null);

  useEffect(() => {
    try {
      const savedBatches = JSON.parse(
        localStorage.getItem("jet-mis-batches") || "[]"
      );
      if (Array.isArray(savedBatches) && savedBatches.length) {
        setBatches(savedBatches);
      }
    } catch {
      // keep samples
    }

    try {
      const savedStudents = JSON.parse(
        localStorage.getItem("jet-mis-admissions") || "[]"
      );

      if (Array.isArray(savedStudents) && savedStudents.length) {
        const mapped: StudentOption[] = savedStudents
          .filter(
            (item: any) =>
              item.studentStatus !== "Dropped" && item.status !== "Dropped"
          )
          .map((item: any) => ({
            id: String(item.admissionId || item.id || "").trim(),
            name: String(
              item.name || item.studentName || item.nameAsPerAadhaar || ""
            ).trim(),
            contact: String(item.contact || item.contactNo || "").trim(),
            course: String(item.course || "").trim(),
          }))
          .filter((item: StudentOption) => item.id && item.name);

        if (mapped.length) setStudents(mapped);
      }
    } catch {
      // keep samples
    }

    try {
      const savedTrainers = JSON.parse(
        localStorage.getItem("jet-mis-trainers") || "[]"
      );

      if (Array.isArray(savedTrainers) && savedTrainers.length) {
        const mapped: TrainerMaster[] = savedTrainers
          .map((item: any) => ({
            id: String(item.id || item.trainerId || "").trim(),
            name: String(item.name || item.trainerName || "").trim(),
            contact: String(item.contact || item.contactNo || "").trim(),
            email: String(item.email || "").trim(),
          }))
          .filter((item: TrainerMaster) => item.id && item.name);

        if (mapped.length) setTrainerOptions(mapped);
      }
    } catch {
      // keep samples
    }
  }, []);

  function saveBatches(updated: Batch[]) {
    setBatches(updated);
    localStorage.setItem("jet-mis-batches", JSON.stringify(updated));
  }

  function replaceBatch(oldId: string, updatedBatch: Batch) {
    const updated = batches.map((batch) =>
      batch.batchId === oldId ? updatedBatch : batch
    );
    saveBatches(updated);

    if (viewBatch?.batchId === oldId) setViewBatch(updatedBatch);
    if (assignmentBatch?.batchId === oldId) setAssignmentBatch(updatedBatch);
  }

  const totalBatches = batches.length;
  const ongoingBatches = batches.filter(
    (batch) => getBatchStatus(batch) === "Ongoing"
  ).length;
  const upcomingBatches = batches.filter(
    (batch) => getBatchStatus(batch) === "Upcoming"
  ).length;
  const completedBatches = batches.filter(
    (batch) => getBatchStatus(batch) === "Completed"
  ).length;

  const filteredBatches = useMemo(() => {
    const term = search.trim().toLowerCase();

    const filtered = batches.filter((batch) => {
      const status = getBatchStatus(batch);
      const matchesSearch = [batch.batchId, batch.batchName, batch.course]
        .join(" ")
        .toLowerCase()
        .includes(term);
      const matchesStatus =
        statusFilter === "All" || status === statusFilter;
      return matchesSearch && matchesStatus;
    });

    filtered.sort((a, b) => {
      const first =
        sortKey === "status" ? getBatchStatus(a) : String(a[sortKey]);
      const second =
        sortKey === "status" ? getBatchStatus(b) : String(b[sortKey]);
      const result = first.localeCompare(second, undefined, {
        numeric: true,
        sensitivity: "base",
      });
      return sortDirection === "asc" ? result : -result;
    });

    return filtered;
  }, [batches, search, statusFilter, sortKey, sortDirection]);

  function handleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDirection((current) => (current === "asc" ? "desc" : "asc"));
      return;
    }
    setSortKey(key);
    setSortDirection("asc");
  }

  function createBatch(batch: Batch) {
    const duplicate = batches.some(
      (item) => item.batchId.toUpperCase() === batch.batchId.toUpperCase()
    );
    if (duplicate) {
      alert("Batch ID already exists.");
      return false;
    }

    saveBatches([...batches, batch]);
    setCreateBatchOpen(false);
    alert("Batch created successfully.");
    return true;
  }

  function updateBatch(oldId: string, updatedBatch: Batch) {
    const duplicate = batches.some(
      (batch) =>
        batch.batchId.toUpperCase() === updatedBatch.batchId.toUpperCase() &&
        batch.batchId !== oldId
    );

    if (duplicate) {
      alert("Batch ID already exists.");
      return false;
    }

    replaceBatch(oldId, updatedBatch);
    setEditBatch(null);
    alert("Batch updated successfully.");
    return true;
  }

  function deleteBatch(batch: Batch) {
    const confirmed = window.confirm(
      `Delete batch "${batch.batchName}"? This action cannot be undone.`
    );
    if (!confirmed) return;

    saveBatches(batches.filter((item) => item.batchId !== batch.batchId));
    setViewBatch(null);
    setActionMenu(null);
    alert("Batch deleted successfully.");
  }

  function saveAssignments(
    batch: Batch,
    studentIds: string[],
    trainers: TrainerAssignment[]
  ) {
    replaceBatch(batch.batchId, {
      ...batch,
      students: studentIds,
      trainers,
    });
    setAssignmentBatch(null);
    alert("Students and trainers updated successfully.");
  }

  function exportExcel() {
    const headers = [
      "Batch ID",
      "Batch Name",
      "Course",
      "Start Date",
      "End Date",
      "Timing",
      "Students",
      "Trainers",
      "Status",
    ];

    const rows = filteredBatches.map((batch) => [
      batch.batchId,
      batch.batchName,
      batch.course,
      formatDate(batch.startDate),
      formatDate(batch.endDate),
      `${formatTime(batch.startTime)} - ${formatTime(batch.endTime)}`,
      `${batch.students.length} / ${batch.maxStudents}`,
      batch.trainers.map((trainer) => `${trainer.name} (${trainer.skill})`).join("; "),
      getBatchStatus(batch),
    ]);

    const escapeCsv = (value: string | number) =>
      `"${String(value ?? "").replace(/"/g, '""')}"`;

    const csv = [headers, ...rows]
      .map((row) => row.map(escapeCsv).join(","))
      .join("\n");

    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "JET-MIS-Batches.csv";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  function openActionMenu(batch: Batch, x: number, y: number) {
    const width = 230;
    const height = 190;
    const padding = 10;

    setActionMenu({
      batch,
      x: Math.max(padding, Math.min(x, window.innerWidth - width - padding)),
      y: Math.max(padding, Math.min(y, window.innerHeight - height - padding)),
    });
  }

  function handleActionButton(
    event: ReactMouseEvent<HTMLButtonElement>,
    batch: Batch
  ) {
    event.stopPropagation();
    const rect = event.currentTarget.getBoundingClientRect();
    openActionMenu(batch, rect.right - 230, rect.bottom + 6);
  }

  function handleRightClick(
    event: ReactMouseEvent<HTMLTableRowElement>,
    batch: Batch
  ) {
    event.preventDefault();
    openActionMenu(batch, event.clientX, event.clientY);
  }

  useEffect(() => {
    function closeMenu(event: MouseEvent) {
      if (
        actionMenuRef.current &&
        !actionMenuRef.current.contains(event.target as Node)
      ) {
        setActionMenu(null);
      }
    }

    function escape(event: KeyboardEvent) {
      if (event.key === "Escape") setActionMenu(null);
    }

    document.addEventListener("mousedown", closeMenu);
    document.addEventListener("keydown", escape);

    return () => {
      document.removeEventListener("mousedown", closeMenu);
      document.removeEventListener("keydown", escape);
    };
  }, []);

  function SortHeader({ label, column }: { label: string; column: SortKey }) {
    const active = sortKey === column;
    return (
      <button
        type="button"
        onClick={() => handleSort(column)}
        className="flex items-center gap-1.5 whitespace-nowrap font-semibold text-slate-800 transition hover:text-blue-700"
      >
        {label}
        {!active && <ChevronDown size={14} className="opacity-30" />}
        {active && sortDirection === "asc" && <ChevronUp size={14} />}
        {active && sortDirection === "desc" && <ChevronDown size={14} />}
      </button>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-xl font-semibold tracking-tight text-neutral-900">
            Batch Management
          </h1>
        </div>

        <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <SummaryCard
            title="Total Batches"
            value={totalBatches}
            icon={<GraduationCap size={20} />}
            tone="blue"
          />
          <SummaryCard
            title="Ongoing Batches"
            value={ongoingBatches}
            icon={<Users size={20} />}
            tone="green"
          />
          <SummaryCard
            title="Upcoming Batches"
            value={upcomingBatches}
            icon={<Clock3 size={20} />}
            tone="blue"
          />
          <SummaryCard
            title="Completed Batches"
            value={completedBatches}
            icon={<Check size={20} />}
            tone="green"
          />
        </div>

        <section>
          <div className="mb-3 flex flex-col gap-3 xl:flex-row xl:items-center">
            <h2 className="shrink-0 text-lg font-semibold text-neutral-900">
              Batches{" "}
              <span className="font-normal text-neutral-400">
                ({filteredBatches.length})
              </span>
            </h2>

            <div className="relative w-full max-w-[480px] xl:ml-4">
              <Search
                size={18}
                strokeWidth={1.7}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400"
              />
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search batch..."
                className="h-11 w-full rounded-lg border border-neutral-200 bg-white pl-10 pr-3 text-sm text-neutral-900 outline-none transition placeholder:text-neutral-400 focus:border-blue-300 focus:ring-2 focus:ring-blue-50"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(event) =>
                setStatusFilter(event.target.value as "All" | BatchStatus)
              }
              className="h-11 w-full rounded-lg border border-neutral-200 bg-white px-3 text-sm text-neutral-700 outline-none transition focus:border-blue-300 focus:ring-2 focus:ring-blue-50 xl:w-[160px]"
            >
              <option value="All">All Status</option>
              <option value="Ongoing">Ongoing</option>
              <option value="Upcoming">Upcoming</option>
              <option value="Completed">Completed</option>
            </select>

            <div className="ml-auto flex shrink-0 items-center gap-2">
              <button
                type="button"
                onClick={() => setCreateBatchOpen(true)}
                className="inline-flex h-11 items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-4 text-sm font-medium text-blue-700 transition hover:bg-blue-100"
              >
                <Plus size={17} strokeWidth={1.8} />
                Create Batch
              </button>

              <button
                type="button"
                onClick={exportExcel}
                className="inline-flex h-11 items-center gap-2 rounded-lg border border-neutral-200 bg-white px-4 text-sm font-medium text-neutral-700 transition hover:bg-neutral-50"
              >
                <Download size={17} strokeWidth={1.8} />
                Excel
              </button>
            </div>
          </div>

          <div className="overflow-hidden rounded-xl border border-neutral-200 bg-white">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1080px] text-left text-sm">
                <thead className="border-b border-neutral-200 bg-neutral-50/80">
                  <tr>
                    <th className="px-4 py-3.5">
                      <SortHeader label="Batch ID" column="batchId" />
                    </th>
                    <th className="px-4 py-3.5">
                      <SortHeader label="Batch Name" column="batchName" />
                    </th>
                    <th className="px-4 py-3.5">
                      <SortHeader label="Course" column="course" />
                    </th>
                    <th className="px-4 py-3.5">
                      <SortHeader label="Start Date" column="startDate" />
                    </th>
                    <th className="px-4 py-3.5 font-semibold text-neutral-700">
                      End Date
                    </th>
                    <th className="px-4 py-3.5 font-semibold text-neutral-700">
                      Timing
                    </th>
                    <th className="px-4 py-3.5 font-semibold text-neutral-700">
                      Students
                    </th>
                    <th className="px-4 py-3.5 font-semibold text-neutral-700">
                      Trainers
                    </th>
                    <th className="px-4 py-3.5">
                      <SortHeader label="Status" column="status" />
                    </th>
                    <th className="w-[60px] px-3 py-3.5" aria-label="Row actions" />
                  </tr>
                </thead>

                <tbody>
                  {filteredBatches.map((batch) => {
                    const status = getBatchStatus(batch);

                    return (
                      <tr
                        key={batch.batchId}
                        onContextMenu={(event) => handleRightClick(event, batch)}
                        className="border-b border-neutral-100 bg-white transition last:border-b-0 hover:bg-blue-50/30"
                      >
                        <td className="whitespace-nowrap px-4 py-3.5 font-medium text-neutral-900">
                          {batch.batchId}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3.5 font-medium text-neutral-900">
                          {batch.batchName}
                        </td>
                        <td className="px-4 py-3.5 text-neutral-700">
                          {batch.course}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3.5 text-neutral-700">
                          {formatDate(batch.startDate)}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3.5 text-neutral-700">
                          {formatDate(batch.endDate)}
                        </td>
                        <td className="whitespace-nowrap px-4 py-3.5 text-neutral-700">
                          {formatTime(batch.startTime)} - {formatTime(batch.endTime)}
                        </td>
                        <td className="px-4 py-3.5 text-neutral-700">
                          {batch.students.length} / {batch.maxStudents}
                        </td>
                        <td className="px-4 py-3.5 text-neutral-700">
                          {batch.trainers.length}
                        </td>
                        <td className="px-4 py-3.5">
                          <BatchStatusBadge status={status} />
                        </td>
                        <td className="w-[60px] px-3 py-3.5 text-center">
                          <button
                            type="button"
                            onClick={(event) => handleActionButton(event, batch)}
                            className="inline-flex h-8 w-8 items-center justify-center rounded-md text-neutral-500 transition hover:bg-blue-50 hover:text-blue-700"
                            aria-label={`Actions for ${batch.batchName}`}
                          >
                            <EllipsisVertical size={18} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}

                  {!filteredBatches.length && (
                    <tr>
                      <td
                        colSpan={10}
                        className="px-4 py-12 text-center text-sm text-neutral-500"
                      >
                        No batches found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>

      {actionMenu && (
        <div
          ref={actionMenuRef}
          style={{ top: actionMenu.y, left: actionMenu.x }}
          className="fixed z-50 w-[230px] rounded-lg border border-slate-200 bg-white p-1.5 shadow-xl"
        >
          <div className="border-b border-slate-100 px-3 py-2.5">
            <p className="truncate text-sm font-semibold text-slate-800">
              {actionMenu.batch.batchName}
            </p>
            <p className="mt-0.5 text-xs text-slate-400">
              {actionMenu.batch.batchId}
            </p>
          </div>

          <MenuButton
            icon={<Eye size={16} />}
            label="View Batch"
            onClick={() => {
              setViewBatch(actionMenu.batch);
              setActionMenu(null);
            }}
          />
          <MenuButton
            icon={<Users size={16} />}
            label="Assign Students / Trainers"
            onClick={() => {
              setAssignmentBatch(actionMenu.batch);
              setActionMenu(null);
            }}
          />
        </div>
      )}

      {createBatchOpen && (
        <BatchFormModal
          title="Create Batch"
          onClose={() => setCreateBatchOpen(false)}
          onSave={createBatch}
        />
      )}

      {viewBatch && (
        <ViewBatchModal
          batch={viewBatch}
          students={students}
          onClose={() => setViewBatch(null)}
          onEdit={() => {
            setEditBatch(viewBatch);
            setViewBatch(null);
          }}
          onDelete={() => deleteBatch(viewBatch)}
        />
      )}

      {editBatch && (
        <BatchFormModal
          title="Edit Batch"
          batch={editBatch}
          onClose={() => setEditBatch(null)}
          onSave={(updated) => updateBatch(editBatch.batchId, updated)}
        />
      )}

      {assignmentBatch && (
        <AssignStudentsTrainersModal
          batch={assignmentBatch}
          batches={batches}
          students={students}
          trainerOptions={trainerOptions}
          onClose={() => setAssignmentBatch(null)}
          onSave={(studentIds, trainers) =>
            saveAssignments(assignmentBatch, studentIds, trainers)
          }
        />
      )}

      <InputStyles />
    </div>
  );
}

function BatchFormModal({
  title,
  batch,
  onClose,
  onSave,
}: {
  title: string;
  batch?: Batch;
  onClose: () => void;
  onSave: (batch: Batch) => boolean;
}) {
  const [form, setForm] = useState<Batch>(
    batch || {
      batchId: "",
      batchName: "",
      course: "",
      startDate: "",
      endDate: "",
      startTime: "",
      endTime: "",
      maxStudents: 25,
      description: "",
      students: [],
      trainers: [],
    }
  );

  function update<K extends keyof Batch>(key: K, value: Batch[K]) {
    setForm((current) => ({ ...current, [key]: value }));
  }

  function submit(event: FormEvent) {
    event.preventDefault();

    if (!form.batchId.trim()) return alert("Batch ID is required.");
    if (!form.batchName.trim()) return alert("Batch Name is required.");
    if (!form.course) return alert("Course is required.");
    if (!form.startDate || !form.endDate)
      return alert("Start Date and End Date are required.");
    if (form.endDate < form.startDate)
      return alert("End Date cannot be before Start Date.");
    if (!form.startTime || !form.endTime)
      return alert("Start Time and End Time are required.");
    if (form.endTime <= form.startTime)
      return alert("End Time must be after Start Time.");
    if (!Number.isInteger(form.maxStudents) || form.maxStudents <= 0)
      return alert("Maximum Students must be a valid positive number.");
    if (form.students.length > form.maxStudents)
      return alert(
        `This batch already has ${form.students.length} students. Maximum Students cannot be lower than that.`
      );

    onSave({
      ...form,
      batchId: form.batchId.trim().toUpperCase(),
      batchName: form.batchName.trim(),
      description: form.description.trim(),
    });
  }

  return (
    <Modal title={title} onClose={onClose} maxWidth="max-w-4xl">
      <form onSubmit={submit}>
        <div className="grid grid-cols-1 gap-5 md:grid-cols-2">
          <Field label="Batch ID" required>
            <input
              value={form.batchId}
              onChange={(event) => update("batchId", event.target.value)}
              placeholder="BAT001"
              className="input-style uppercase"
            />
          </Field>

          <Field label="Batch Name" required>
            <input
              value={form.batchName}
              onChange={(event) => update("batchName", event.target.value)}
              placeholder="Full Stack Morning"
              className="input-style"
            />
          </Field>

          <Field label="Course" required>
            <select
              value={form.course}
              onChange={(event) => update("course", event.target.value)}
              className="input-style"
            >
              <option value="">Select Course</option>
              {courseOptions.map((course) => (
                <option key={course}>{course}</option>
              ))}
            </select>
          </Field>

          <Field label="Maximum Students" required>
            <input
              type="number"
              min="1"
              value={form.maxStudents}
              onChange={(event) =>
                update("maxStudents", Number(event.target.value) || 0)
              }
              className="input-style"
            />
          </Field>

          <Field label="Start Date" required>
            <input
              type="date"
              value={form.startDate}
              onChange={(event) => update("startDate", event.target.value)}
              className="input-style"
            />
          </Field>

          <Field label="End Date" required>
            <input
              type="date"
              value={form.endDate}
              min={form.startDate}
              onChange={(event) => update("endDate", event.target.value)}
              className="input-style"
            />
          </Field>

          <Field label="Start Time" required>
            <input
              type="time"
              value={form.startTime}
              onChange={(event) => update("startTime", event.target.value)}
              className="input-style"
            />
          </Field>

          <Field label="End Time" required>
            <input
              type="time"
              value={form.endTime}
              onChange={(event) => update("endTime", event.target.value)}
              className="input-style"
            />
          </Field>

          <div className="md:col-span-2">
            <Field label="Description">
              <textarea
                value={form.description}
                onChange={(event) => update("description", event.target.value)}
                rows={4}
                placeholder="Optional batch description..."
                className="textarea-style"
              />
            </Field>
          </div>
        </div>

        <div className="mt-6 flex justify-end gap-3 border-t border-slate-100 pt-5">
          <SecondaryButton onClick={onClose}>Cancel</SecondaryButton>
          <PrimaryButton type="submit">
            {batch ? "Save Changes" : "Create Batch"}
          </PrimaryButton>
        </div>
      </form>
    </Modal>
  );
}

function ViewBatchModal({
  batch,
  students,
  onClose,
  onEdit,
  onDelete,
}: {
  batch: Batch;
  students: StudentOption[];
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}) {
  const assignedStudents = students.filter((student) =>
    batch.students.includes(student.id)
  );

  return (
    <Modal title="Batch Details" onClose={onClose} maxWidth="max-w-5xl">
      <div className="mb-6 flex items-start justify-between gap-4">
        <div>
          <h3 className="text-xl font-semibold text-slate-800">
            {batch.batchName}
          </h3>
          <p className="mt-1 text-sm text-slate-500">
            {batch.batchId} • {batch.course}
          </p>
        </div>
        <BatchStatusBadge status={getBatchStatus(batch)} />
      </div>

      <div className="mb-7 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <InfoBox
          label="Duration"
          value={`${formatDate(batch.startDate)} - ${formatDate(batch.endDate)}`}
          tone="blue"
        />
        <InfoBox
          label="Timing"
          value={`${formatTime(batch.startTime)} - ${formatTime(batch.endTime)}`}
          tone="blue"
        />
        <InfoBox
          label="Students"
          value={`${batch.students.length} / ${batch.maxStudents}`}
          tone="green"
        />
        <InfoBox
          label="Trainers"
          value={String(batch.trainers.length)}
          tone="green"
        />
      </div>

      {batch.description && (
        <div className="mb-7 rounded-lg border border-slate-200 bg-slate-50/70 p-4">
          <p className="text-xs font-medium uppercase tracking-wide text-slate-400">
            Description
          </p>
          <p className="mt-1.5 text-sm text-slate-600">{batch.description}</p>
        </div>
      )}

      <section className="mb-7">
        <h4 className="mb-3 text-sm font-semibold text-slate-700">
          Assigned Trainers
        </h4>

        <div className="overflow-hidden rounded-lg border border-slate-200">
          {batch.trainers.length ? (
            <table className="w-full text-sm">
              <thead className="bg-green-50/50 text-left">
                <tr>
                  <th className="px-4 py-3 font-semibold text-slate-800">
                    Trainer
                  </th>
                  <th className="px-4 py-3 font-semibold text-slate-800">
                    Skill / Module
                  </th>
                  <th className="px-4 py-3 font-semibold text-slate-800">
                    Contact
                  </th>
                </tr>
              </thead>
              <tbody>
                {batch.trainers.map((trainer) => (
                  <tr key={trainer.id} className="border-t border-slate-100">
                    <td className="px-4 py-3 font-medium text-slate-700">
                      {trainer.name}
                    </td>
                    <td className="px-4 py-3 text-slate-600">{trainer.skill}</td>
                    <td className="px-4 py-3 text-slate-600">
                      {trainer.contact || "-"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <EmptyBox>No trainers assigned.</EmptyBox>
          )}
        </div>
      </section>

      <section className="mb-7">
        <h4 className="mb-3 text-sm font-semibold text-slate-700">
          Assigned Students
        </h4>

        <div className="overflow-hidden rounded-lg border border-slate-200">
          {assignedStudents.length ? (
            <table className="w-full text-sm">
              <thead className="bg-blue-50/50 text-left">
                <tr>
                  <th className="px-4 py-3 font-semibold text-slate-800">
                    Admission ID
                  </th>
                  <th className="px-4 py-3 font-semibold text-slate-800">
                    Student Name
                  </th>
                  <th className="px-4 py-3 font-semibold text-slate-800">
                    Contact
                  </th>
                  <th className="px-4 py-3 font-semibold text-slate-800">
                    Course
                  </th>
                </tr>
              </thead>
              <tbody>
                {assignedStudents.map((student) => (
                  <tr key={student.id} className="border-t border-slate-100">
                    <td className="px-4 py-3 font-medium text-slate-700">
                      {student.id}
                    </td>
                    <td className="px-4 py-3 text-slate-600">{student.name}</td>
                    <td className="px-4 py-3 text-slate-600">
                      {student.contact || "-"}
                    </td>
                    <td className="px-4 py-3 text-slate-600">{student.course}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <EmptyBox>No students assigned.</EmptyBox>
          )}
        </div>
      </section>

      <div className="flex justify-end gap-3 border-t border-slate-100 pt-5">
        <button
          type="button"
          onClick={onEdit}
          className="inline-flex h-10 items-center gap-2 rounded-md border border-blue-200 bg-blue-50 px-4 text-sm font-medium text-blue-700 transition hover:bg-blue-100"
        >
          <Edit3 size={16} />
          Edit Batch
        </button>

        <button
          type="button"
          onClick={onDelete}
          className="inline-flex h-10 items-center gap-2 rounded-md border border-red-200 bg-red-50 px-4 text-sm font-medium text-red-600 transition hover:bg-red-100"
        >
          <Trash2 size={16} />
          Delete Batch
        </button>
      </div>
    </Modal>
  );
}

function AssignStudentsTrainersModal({
  batch,
  batches,
  students,
  trainerOptions,
  onClose,
  onSave,
}: {
  batch: Batch;
  batches: Batch[];
  students: StudentOption[];
  trainerOptions: TrainerMaster[];
  onClose: () => void;
  onSave: (studentIds: string[], trainers: TrainerAssignment[]) => void;
}) {
  const [search, setSearch] = useState("");
  const [selectedStudents, setSelectedStudents] = useState<string[]>(batch.students);
  const [trainers, setTrainers] = useState<TrainerAssignment[]>(
    batch.trainers.map((trainer) => ({ ...trainer }))
  );
  const [selectedTrainerId, setSelectedTrainerId] = useState("");
  const [skill, setSkill] = useState("");

  const assignedStudents = students.filter((student) =>
    selectedStudents.includes(student.id)
  );

  const assignedToOtherBatches = useMemo(
    () =>
      new Set(
        batches
          .filter((item) => item.batchId !== batch.batchId)
          .flatMap((item) => item.students)
      ),
    [batches, batch.batchId]
  );

  const unassignedStudents = students.filter(
    (student) =>
      !selectedStudents.includes(student.id) &&
      !assignedToOtherBatches.has(student.id)
  );

  const filteredStudents = unassignedStudents.filter((student) =>
    [student.id, student.name, student.contact, student.course]
      .join(" ")
      .toLowerCase()
      .includes(search.trim().toLowerCase())
  );

  const availableTrainers = trainerOptions.filter(
    (trainer) => !trainers.some((assigned) => assigned.id === trainer.id)
  );

  function addStudent(studentId: string) {
    if (selectedStudents.length >= batch.maxStudents) {
      alert(`Maximum ${batch.maxStudents} students allowed in this batch.`);
      return;
    }
    setSelectedStudents((current) => [...current, studentId]);
  }

  function removeStudent(studentId: string) {
    setSelectedStudents((current) => current.filter((id) => id !== studentId));
  }

  function addTrainer() {
    if (!selectedTrainerId) {
      alert("Please select a trainer.");
      return;
    }
    if (!skill.trim()) {
      alert("Please enter the Skill / Module for this trainer.");
      return;
    }
    const trainer = trainerOptions.find((item) => item.id === selectedTrainerId);
    if (!trainer) return;
    setTrainers((current) => [...current, { ...trainer, skill: skill.trim() }]);
    setSelectedTrainerId("");
    setSkill("");
  }

  function removeTrainer(trainerId: string) {
    setTrainers((current) => current.filter((item) => item.id !== trainerId));
  }

  function updateSkill(trainerId: string, value: string) {
    setTrainers((current) =>
      current.map((trainer) =>
        trainer.id === trainerId ? { ...trainer, skill: value } : trainer
      )
    );
  }

  function save() {
    if (trainers.some((trainer) => !trainer.skill.trim())) {
      alert("Skill / Module is required for every assigned trainer.");
      return;
    }
    onSave(
      selectedStudents,
      trainers.map((trainer) => ({ ...trainer, skill: trainer.skill.trim() }))
    );
  }

  return (
    <Modal title="Assign Students / Trainers" onClose={onClose} maxWidth="max-w-6xl">
      <div className="mb-6 rounded-lg border border-blue-100 bg-blue-50/40 p-4">
        <p className="font-semibold text-slate-800">{batch.batchName}</p>
        <p className="mt-1 text-sm text-slate-500">
          {batch.batchId} • {batch.course}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold text-slate-800">Assign Students</h3>
              <p className="mt-0.5 text-xs text-slate-400">
                Assigned students are shown first. Search or scroll through unassigned students below.
              </p>
            </div>
            <span className="shrink-0 rounded-full border border-green-200 bg-green-50 px-2.5 py-1 text-xs font-medium text-green-700">
              {selectedStudents.length} / {batch.maxStudents}
            </span>
          </div>

          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
            Assigned Students
          </p>
          {assignedStudents.length ? (
            <div className="mb-5 flex max-h-[120px] flex-wrap gap-2 overflow-y-auto rounded-lg border border-green-100 bg-green-50/30 p-3">
              {assignedStudents.map((student) => (
                <div key={student.id} className="inline-flex items-center gap-2 rounded-full border border-green-200 bg-white px-3 py-1.5 text-sm text-green-700">
                  <Check size={13} />
                  <span>{student.name}</span>
                  <button type="button" onClick={() => removeStudent(student.id)} className="rounded-full p-0.5 text-green-500 hover:bg-red-50 hover:text-red-600" aria-label={`Remove ${student.name}`}>
                    <X size={13} />
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <div className="mb-5 rounded-lg border border-dashed border-slate-200 bg-slate-50/60 px-4 py-4 text-sm text-slate-400">
              No students assigned yet.
            </div>
          )}

          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
            Unassigned Students
          </p>
          <div className="relative mb-3">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search student..." className="input-style pl-9" />
          </div>

          <div className="h-[330px] overflow-y-auto rounded-lg border border-slate-200 bg-white">
            {filteredStudents.map((student) => (
              <div key={student.id} className="flex items-center justify-between gap-4 border-b border-slate-100 px-4 py-3 last:border-0 hover:bg-blue-50/30">
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium text-slate-700">{student.name}</p>
                  <p className="mt-0.5 text-xs text-slate-400">{student.id} • {student.contact || "No contact"}</p>
                  <p className="mt-0.5 text-xs text-slate-500">{student.course || "Course not specified"}</p>
                </div>
                <button type="button" onClick={() => addStudent(student.id)} className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-md border border-blue-200 bg-blue-50 px-3 text-xs font-medium text-blue-700 hover:bg-blue-100">
                  <Plus size={14} /> Add
                </button>
              </div>
            ))}
            {!filteredStudents.length && <EmptyBox>No unassigned students found.</EmptyBox>}
          </div>
        </section>

        <section className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <h3 className="font-semibold text-slate-800">Assign Trainers</h3>
              <p className="mt-0.5 text-xs text-slate-400">
                Select a trainer and mention the module or skill they will teach.
              </p>
            </div>
            <span className="shrink-0 rounded-full border border-green-200 bg-green-50 px-2.5 py-1 text-xs font-medium text-green-700">
              {trainers.length} Trainer{trainers.length === 1 ? "" : "s"}
            </span>
          </div>

          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
            Assigned Trainers
          </p>
          {trainers.length ? (
            <div className="mb-5 space-y-2 rounded-lg border border-green-100 bg-green-50/30 p-3">
              {trainers.map((trainer) => (
                <div key={trainer.id} className="rounded-lg border border-green-200 bg-white p-3">
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-700">{trainer.name}</p>
                      <p className="mt-0.5 text-xs text-slate-400">{trainer.contact || "No contact"}</p>
                    </div>
                    <button type="button" onClick={() => removeTrainer(trainer.id)} className="inline-flex h-8 items-center gap-1 rounded-md border border-red-200 bg-red-50 px-2.5 text-xs font-medium text-red-600 hover:bg-red-100">
                      <X size={13} /> Remove
                    </button>
                  </div>
                  <input value={trainer.skill} onChange={(event) => updateSkill(trainer.id, event.target.value)} placeholder="Skill / Module" className="input-style" />
                </div>
              ))}
            </div>
          ) : (
            <div className="mb-5 rounded-lg border border-dashed border-slate-200 bg-slate-50/60 px-4 py-4 text-sm text-slate-400">
              No trainers assigned yet.
            </div>
          )}

          <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
            Add Trainer
          </p>
          <div className="space-y-3 rounded-lg border border-blue-100 bg-blue-50/30 p-4">
            <Field label="Trainer" required>
              <select value={selectedTrainerId} onChange={(event) => setSelectedTrainerId(event.target.value)} className="input-style">
                <option value="">Select Trainer</option>
                {availableTrainers.map((trainer) => (
                  <option key={trainer.id} value={trainer.id}>{trainer.name}</option>
                ))}
              </select>
            </Field>
            <Field label="Skill / Module" required>
              <input value={skill} onChange={(event) => setSkill(event.target.value)} placeholder="Ex: Front-End Development" className="input-style" />
            </Field>
            <button type="button" onClick={addTrainer} disabled={!availableTrainers.length} className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-blue-200 bg-blue-50 px-4 text-sm font-medium text-blue-700 hover:bg-blue-100 disabled:cursor-not-allowed disabled:opacity-40">
              <UserPlus size={16} /> Add Trainer
            </button>
          </div>
        </section>
      </div>

      <div className="mt-6 flex justify-end gap-3 border-t border-slate-100 pt-5">
        <SecondaryButton onClick={onClose}>Cancel</SecondaryButton>
        <PrimaryButton onClick={save}>Save Assignments</PrimaryButton>
      </div>
    </Modal>
  );
}

function SummaryCard({
  title,
  value,
  icon,
  tone,
}: {
  title: string;
  value: number;
  icon: ReactNode;
  tone: "blue" | "green";
}) {
  const toneClass =
    tone === "green"
      ? "border-green-100 bg-green-50/50 text-green-700"
      : "border-blue-100 bg-blue-50/50 text-blue-700";

  return (
    <div className={`rounded-xl border p-5 ${toneClass}`}>
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium">{title}</p>
        <span className="opacity-70">{icon}</span>
      </div>
      <p className="mt-2 text-3xl font-semibold text-slate-800">{value}</p>
    </div>
  );
}

function BatchStatusBadge({ status }: { status: BatchStatus }) {
  const classes =
    status === "Ongoing"
      ? "border-green-200 bg-green-50 text-green-700"
      : status === "Upcoming"
        ? "border-blue-200 bg-blue-50 text-blue-700"
        : "border-slate-200 bg-slate-50 text-slate-600";

  return (
    <span
      className={`inline-flex rounded-full border px-2.5 py-1 text-xs font-medium ${classes}`}
    >
      {status}
    </span>
  );
}

function MenuButton({
  icon,
  label,
  onClick,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex w-full items-center gap-3 rounded-md px-3 py-2.5 text-left text-sm font-medium text-slate-600 transition hover:bg-blue-50 hover:text-blue-700"
    >
      {icon}
      {label}
    </button>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <div className="mb-1.5 text-sm font-medium text-slate-600">
        {label}
        {required && <span className="ml-1 text-red-500">*</span>}
      </div>
      {children}
    </label>
  );
}

function InfoBox({
  label,
  value,
  tone,
}: {
  label: string;
  value: string;
  tone: "blue" | "green";
}) {
  const classes =
    tone === "green"
      ? "border-green-100 bg-green-50/40"
      : "border-blue-100 bg-blue-50/40";

  return (
    <div className={`rounded-lg border p-4 ${classes}`}>
      <p className="text-xs text-slate-400">{label}</p>
      <p className="mt-1 text-sm font-semibold text-slate-700">{value}</p>
    </div>
  );
}

function EmptyBox({ children }: { children: ReactNode }) {
  return (
    <div className="bg-slate-50/50 p-6 text-center text-sm text-slate-400">
      {children}
    </div>
  );
}

function SecondaryButton({
  children,
  onClick,
}: {
  children: ReactNode;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="h-10 rounded-md border border-slate-200 bg-white px-4 text-sm font-medium text-slate-600 transition hover:bg-slate-50"
    >
      {children}
    </button>
  );
}

function PrimaryButton({
  children,
  onClick,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className="h-10 rounded-md border border-blue-200 bg-blue-50 px-5 text-sm font-medium text-blue-700 transition hover:bg-blue-100"
    >
      {children}
    </button>
  );
}

function Modal({
  title,
  children,
  onClose,
  maxWidth = "max-w-2xl",
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  maxWidth?: string;
}) {
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-900/20 px-4 py-6 backdrop-blur-[1px]">
      <div
        className={`max-h-[92vh] w-full ${maxWidth} overflow-y-auto rounded-xl border border-slate-200 bg-white shadow-xl`}
      >
        <div className="sticky top-0 z-20 flex items-center justify-between border-b border-slate-100 bg-white/95 px-5 py-4 backdrop-blur">
          <h3 className="text-lg font-semibold text-slate-800">{title}</h3>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 text-slate-400 transition hover:bg-red-50 hover:text-red-600"
            aria-label="Close"
          >
            <X size={18} />
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

function InputStyles() {
  return (
    <style jsx global>{`
      .input-style {
        height: 40px;
        width: 100%;
        border-radius: 6px;
        border: 1px solid rgb(226 232 240);
        background: white;
        padding: 0 12px;
        font-size: 14px;
        color: rgb(51 65 85);
        outline: none;
        transition: border-color 150ms ease, box-shadow 150ms ease,
          background-color 150ms ease;
      }

      .input-style:focus {
        border-color: rgb(147 197 253);
        box-shadow: 0 0 0 3px rgb(239 246 255);
      }

      .input-style::placeholder {
        color: rgb(148 163 184);
      }

      .textarea-style {
        width: 100%;
        resize: none;
        border-radius: 6px;
        border: 1px solid rgb(226 232 240);
        background: white;
        padding: 10px 12px;
        font-size: 14px;
        color: rgb(51 65 85);
        outline: none;
        transition: border-color 150ms ease, box-shadow 150ms ease;
      }

      .textarea-style:focus {
        border-color: rgb(147 197 253);
        box-shadow: 0 0 0 3px rgb(239 246 255);
      }

      .textarea-style::placeholder {
        color: rgb(148 163 184);
      }
    `}</style>
  );
}
