"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  ArrowUpDown,
  CalendarDays,
  ChevronDown,
  ChevronUp,
  Download,
  EllipsisVertical,
  Pencil,
  Search,
  Trash2,
  UserRoundCheck,
  UserRoundPlus,
  Users,
} from "lucide-react";
import {
  MouseEvent as ReactMouseEvent,
  ReactNode,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

/* =========================================================
   TYPES
========================================================= */

type SortDirection = "asc" | "desc";

type EnquirySortKey =
  | "date"
  | "name"
  | "contact"
  | "course"
  | "source"
  | "committedFee"
  | "remark";

type Enquiry = {
  id: string;
  date: string;
  name: string;
  contact: string;
  email: string;
  guardianName: string;
  guardianContact: string;
  qualification: string;
  course: string;
  source: string;
  committedFee: number;
  remark: string;
};

type ActionMenu =
  | {
      enquiry: Enquiry;
      x: number;
      y: number;
    }
  | null;

/* =========================================================
   SAMPLE ENQUIRY DATA
========================================================= */

const sampleEnquiries: Enquiry[] = [
  {
    id: "ENQ001",
    date: "2026-09-05",
    name: "Arun Kumar",
    contact: "9876543210",
    email: "arun@gmail.com",
    guardianName: "Ramesh Kumar",
    guardianContact: "9876500000",
    qualification: "B.E",
    course: "Full Stack Development",
    source: "Walk-in",
    committedFee: 30000,
    remark: "Interested. Follow up tomorrow.",
  },
  {
    id: "ENQ002",
    date: "2026-09-04",
    name: "Karthik R",
    contact: "9876543211",
    email: "karthik@gmail.com",
    guardianName: "Rajendran",
    guardianContact: "9876500001",
    qualification: "B.Sc",
    course: "Python Programming",
    source: "Referral",
    committedFee: 25000,
    remark: "Will confirm after discussion.",
  },
  {
    id: "ENQ003",
    date: "2026-09-03",
    name: "Priya S",
    contact: "9876543212",
    email: "priya@gmail.com",
    guardianName: "Suresh",
    guardianContact: "9876500002",
    qualification: "B.Com",
    course: "Beautician",
    source: "Instagram",
    committedFee: 20000,
    remark: "Requested course timing details.",
  },
  {
    id: "ENQ004",
    date: "2026-09-02",
    name: "Suresh M",
    contact: "9876543213",
    email: "suresh@gmail.com",
    guardianName: "Murugan",
    guardianContact: "9876500003",
    qualification: "BCA",
    course: "Data Analytics",
    source: "Website",
    committedFee: 35000,
    remark: "Interested in weekend batch.",
  },
  {
    id: "ENQ005",
    date: "2026-09-01",
    name: "Deepa R",
    contact: "9876543214",
    email: "deepa@gmail.com",
    guardianName: "Ravi",
    guardianContact: "9876500004",
    qualification: "B.Sc",
    course: "Fashion Designing",
    source: "Facebook",
    committedFee: 30000,
    remark: "Needs fee details.",
  },
  {
    id: "ENQ006",
    date: "2026-08-30",
    name: "Vignesh K",
    contact: "9876543215",
    email: "vignesh@gmail.com",
    guardianName: "Kumar",
    guardianContact: "9876500005",
    qualification: "B.E",
    course: "Java Full Stack Development",
    source: "Walk-in",
    committedFee: 40000,
    remark: "Ready to join next batch.",
  },
  {
    id: "ENQ007",
    date: "2026-08-28",
    name: "Nandhini P",
    contact: "9876543216",
    email: "nandhini@gmail.com",
    guardianName: "Prakash",
    guardianContact: "9876500006",
    qualification: "HSC",
    course: "Beautician",
    source: "Referral",
    committedFee: 22000,
    remark: "Asked for batch start date.",
  },
  {
    id: "ENQ008",
    date: "2026-08-25",
    name: "Ajith R",
    contact: "9876543217",
    email: "ajith@gmail.com",
    guardianName: "Ramesh",
    guardianContact: "9876500007",
    qualification: "B.Tech",
    course: "Web Development",
    source: "Google",
    committedFee: 28000,
    remark: "Follow up next week.",
  },
  {
    id: "ENQ009",
    date: "2026-08-22",
    name: "Keerthana S",
    contact: "9876543218",
    email: "keerthana@gmail.com",
    guardianName: "Sekar",
    guardianContact: "9876500008",
    qualification: "B.Com",
    course: "Fashion Designing",
    source: "Instagram",
    committedFee: 32000,
    remark: "Interested in morning batch.",
  },
  {
    id: "ENQ010",
    date: "2026-08-20",
    name: "Mohamed Irfan",
    contact: "9876543219",
    email: "irfan@gmail.com",
    guardianName: "Abdul Rahman",
    guardianContact: "9876500009",
    qualification: "BCA",
    course: "UI/UX Designing",
    source: "WhatsApp",
    committedFee: 30000,
    remark: "Requested syllabus.",
  },
];

/* =========================================================
   HELPERS
========================================================= */

function getLocalDate() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function formatDate(date: string) {
  if (!date) return "-";
  return new Date(`${date}T00:00:00`).toLocaleDateString("en-GB");
}

function csvCell(value: string | number) {
  return `"${String(value ?? "").replace(/"/g, '""')}"`;
}

/* =========================================================
   PAGE
========================================================= */

export default function LeadManagementPage() {
  const router = useRouter();

  const [enquiries, setEnquiries] =
    useState<Enquiry[]>(sampleEnquiries);

  const [search, setSearch] = useState("");

  const [sortKey, setSortKey] =
    useState<EnquirySortKey>("date");

  const [sortDirection, setSortDirection] =
    useState<SortDirection>("desc");

  const [actionMenu, setActionMenu] =
    useState<ActionMenu>(null);

  const actionMenuRef = useRef<HTMLDivElement | null>(null);

  const [admissionsThisMonth, setAdmissionsThisMonth] =
    useState(0);

  /* =========================================================
     ADMISSIONS THIS MONTH
  ========================================================= */

  useEffect(() => {
    try {
      const admissions = JSON.parse(
        localStorage.getItem("jet-mis-admissions") || "[]"
      );

      if (!Array.isArray(admissions)) {
        setAdmissionsThisMonth(0);
        return;
      }

      const now = new Date();

      const count = admissions.filter((item: any) => {
        if (!item?.admissionDate) return false;

        const date = new Date(
          `${item.admissionDate}T00:00:00`
        );

        return (
          date.getMonth() === now.getMonth() &&
          date.getFullYear() === now.getFullYear()
        );
      }).length;

      setAdmissionsThisMonth(count);
    } catch {
      setAdmissionsThisMonth(0);
    }
  }, []);

  /* =========================================================
     SUMMARY
  ========================================================= */

  const totalEnquiries = enquiries.length;

  const enquiriesThisMonth = useMemo(() => {
    const now = new Date();

    return enquiries.filter((item) => {
      const date = new Date(`${item.date}T00:00:00`);

      return (
        date.getMonth() === now.getMonth() &&
        date.getFullYear() === now.getFullYear()
      );
    }).length;
  }, [enquiries]);

  /* =========================================================
     FILTER + SORT
  ========================================================= */

  const filteredEnquiries = useMemo(() => {
    const term = search.trim().toLowerCase();

    const filtered = enquiries.filter((item) =>
      [
        item.id,
        item.date,
        item.name,
        item.contact,
        item.email,
        item.guardianName,
        item.qualification,
        item.course,
        item.source,
        item.committedFee,
        item.remark,
      ]
        .join(" ")
        .toLowerCase()
        .includes(term)
    );

    filtered.sort((a, b) => {
      let aValue: string | number = a[sortKey];
      let bValue: string | number = b[sortKey];

      if (sortKey === "date") {
        aValue = new Date(
          `${a.date}T00:00:00`
        ).getTime();

        bValue = new Date(
          `${b.date}T00:00:00`
        ).getTime();
      }

      if (sortKey === "committedFee") {
        return sortDirection === "asc"
          ? Number(aValue) - Number(bValue)
          : Number(bValue) - Number(aValue);
      }

      const comparison = String(aValue).localeCompare(
        String(bValue),
        undefined,
        {
          numeric: true,
          sensitivity: "base",
        }
      );

      return sortDirection === "asc"
        ? comparison
        : -comparison;
    });

    return filtered;
  }, [enquiries, search, sortKey, sortDirection]);

  /* =========================================================
     SORT
  ========================================================= */

  function handleSort(column: EnquirySortKey) {
    if (sortKey === column) {
      setSortDirection((current) =>
        current === "asc" ? "desc" : "asc"
      );

      return;
    }

    setSortKey(column);
    setSortDirection("asc");
  }

  /* =========================================================
     EXCEL
  ========================================================= */

  function handleExcel() {
    if (!filteredEnquiries.length) {
      alert("No enquiry data available to download.");
      return;
    }

    const headers = [
      "Enquiry ID",
      "Enquiry Date",
      "Candidate Name",
      "Contact No",
      "Email",
      "Guardian Name",
      "Guardian Contact",
      "Qualification",
      "Course Interested",
      "Source",
      "Committed Fee",
      "Remark",
    ];

    const rows = filteredEnquiries.map((item) => [
      item.id,
      formatDate(item.date),
      item.name,
      item.contact,
      item.email,
      item.guardianName,
      item.guardianContact,
      item.qualification,
      item.course,
      item.source,
      item.committedFee,
      item.remark,
    ]);

    const csvContent = [
      headers.map(csvCell).join(","),
      ...rows.map((row) =>
        row.map(csvCell).join(",")
      ),
    ].join("\n");

    const blob = new Blob(
      ["\uFEFF" + csvContent],
      {
        type: "text/csv;charset=utf-8;",
      }
    );

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.download = `JET-MIS-Enquiries-${getLocalDate()}.csv`;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
  }

  /* =========================================================
     ACTION MENU
  ========================================================= */

  function openActionMenu(
    enquiry: Enquiry,
    x: number,
    y: number
  ) {
    const width = 220;
    const height = 190;
    const padding = 10;

    setActionMenu({
      enquiry,
      x: Math.max(
        padding,
        Math.min(
          x,
          window.innerWidth - width - padding
        )
      ),
      y: Math.max(
        padding,
        Math.min(
          y,
          window.innerHeight - height - padding
        )
      ),
    });
  }

  function handleActionButton(
    event: ReactMouseEvent<HTMLButtonElement>,
    enquiry: Enquiry
  ) {
    event.stopPropagation();

    const rect =
      event.currentTarget.getBoundingClientRect();

    openActionMenu(
      enquiry,
      rect.right - 220,
      rect.bottom + 6
    );
  }

  function handleRightClick(
    event: ReactMouseEvent<HTMLTableRowElement>,
    enquiry: Enquiry
  ) {
    event.preventDefault();

    openActionMenu(
      enquiry,
      event.clientX,
      event.clientY
    );
  }

  useEffect(() => {
    function closeMenu(event: MouseEvent) {
      if (
        actionMenuRef.current &&
        !actionMenuRef.current.contains(
          event.target as Node
        )
      ) {
        setActionMenu(null);
      }
    }

    function escapeMenu(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setActionMenu(null);
      }
    }

    document.addEventListener(
      "mousedown",
      closeMenu
    );

    document.addEventListener(
      "keydown",
      escapeMenu
    );

    return () => {
      document.removeEventListener(
        "mousedown",
        closeMenu
      );

      document.removeEventListener(
        "keydown",
        escapeMenu
      );
    };
  }, []);

  function editEnquiry(enquiry: Enquiry) {
    setActionMenu(null);

    router.push(
      `/leads/edit-enquiry?id=${encodeURIComponent(
        enquiry.id
      )}`
    );
  }

  function convertEnquiry(enquiry: Enquiry) {
    setActionMenu(null);

    const query = new URLSearchParams({
      enquiryId: enquiry.id,
      name: enquiry.name,
      contact: enquiry.contact,
      email: enquiry.email,
      guardianName: enquiry.guardianName,
      guardianContact: enquiry.guardianContact,
      qualification: enquiry.qualification,
      course: enquiry.course,
      committedFee: String(
        enquiry.committedFee
      ),
    });

    router.push(
      `/leads/new-admission?${query.toString()}`
    );
  }

  function deleteEnquiry(enquiry: Enquiry) {
    const confirmed = window.confirm(
      `Delete enquiry "${enquiry.name}"?`
    );

    if (!confirmed) return;

    setEnquiries((current) =>
      current.filter(
        (item) => item.id !== enquiry.id
      )
    );

    setActionMenu(null);

    alert("Enquiry deleted successfully.");
  }

  /* =========================================================
     SORT HEADER
  ========================================================= */

  function SortHeader({
    label,
    column,
  }: {
    label: string;
    column: EnquirySortKey;
  }) {
    const active = sortKey === column;

    return (
      <button
        type="button"
        onClick={() => handleSort(column)}
        className="flex items-center gap-1.5 whitespace-nowrap font-semibold text-neutral-700 transition hover:text-blue-700"
      >
        {label}

        {!active && (
          <ArrowUpDown
            size={14}
            strokeWidth={1.7}
            className="text-neutral-400"
          />
        )}

        {active &&
          sortDirection === "asc" && (
            <ChevronUp
              size={14}
              strokeWidth={1.8}
              className="text-blue-600"
            />
          )}

        {active &&
          sortDirection === "desc" && (
            <ChevronDown
              size={14}
              strokeWidth={1.8}
              className="text-blue-600"
            />
          )}
      </button>
    );
  }

  /* =========================================================
     PAGE
  ========================================================= */

  return (
    <div className="min-h-screen bg-white">
      <div className="p-6">
        {/* PAGE TITLE */}

        <div className="mb-6">
          <h1 className="text-xl font-semibold tracking-tight text-neutral-900">
            Lead Management
          </h1>
        </div>

        {/* SUMMARY CARDS */}

        <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          <SummaryCard
            title="Total Enquiries"
            value={totalEnquiries}
            icon={<Users size={20} />}
            tone="blue"
          />

          <SummaryCard
            title="Enquiries This Month"
            value={enquiriesThisMonth}
            icon={<CalendarDays size={20} />}
            tone="green"
          />

          <SummaryCard
            title="Admissions This Month"
            value={admissionsThisMonth}
            icon={
              <UserRoundCheck size={20} />
            }
            tone="blue"
          />
        </div>

        {/* ENQUIRIES */}

        <section>
          {/* TOOLBAR */}

          <div className="mb-3 flex flex-col gap-3 xl:flex-row xl:items-center">
            <h2 className="shrink-0 text-lg font-semibold text-neutral-900">
              Enquiries{" "}
              <span className="font-normal text-neutral-400">
                ({filteredEnquiries.length})
              </span>
            </h2>

            <div className="relative w-full max-w-[480px] xl:ml-4">
              <Search
                size={18}
                strokeWidth={1.7}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400"
              />

              <input
                type="text"
                value={search}
                onChange={(event) =>
                  setSearch(event.target.value)
                }
                placeholder="Search enquiry..."
                className="h-11 w-full rounded-lg border border-neutral-200 bg-white pl-10 pr-3 text-sm text-neutral-900 outline-none transition placeholder:text-neutral-400 focus:border-blue-300 focus:ring-2 focus:ring-blue-50"
              />
            </div>

            <div className="ml-auto flex shrink-0 items-center gap-2">
              <Link
                href="/leads/new-enquiry"
                className="inline-flex h-11 items-center gap-2 rounded-lg border border-blue-200 bg-blue-50 px-4 text-sm font-medium text-blue-700 transition hover:bg-blue-100"
              >
                <UserRoundPlus
                  size={17}
                  strokeWidth={1.8}
                />

                New Enquiry
              </Link>

              <button
                type="button"
                onClick={handleExcel}
                className="inline-flex h-11 items-center gap-2 rounded-lg border border-neutral-200 bg-white px-4 text-sm font-medium text-neutral-700 transition hover:bg-neutral-50"
              >
                <Download
                  size={17}
                  strokeWidth={1.8}
                />

                Excel
              </button>
            </div>
          </div>

          {/* TABLE */}

          <div className="overflow-hidden rounded-xl border border-neutral-200 bg-white">
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1180px] text-left text-sm">
                <thead className="border-b border-neutral-200 bg-neutral-50/80">
                  <tr>
                    <th className="px-4 py-3.5">
                      <SortHeader
                        label="Enquiry Date"
                        column="date"
                      />
                    </th>

                    <th className="px-4 py-3.5">
                      <SortHeader
                        label="Candidate Name"
                        column="name"
                      />
                    </th>

                    <th className="px-4 py-3.5">
                      <SortHeader
                        label="Contact No"
                        column="contact"
                      />
                    </th>

                    <th className="px-4 py-3.5">
                      <SortHeader
                        label="Course Interested"
                        column="course"
                      />
                    </th>

                    <th className="px-4 py-3.5">
                      <SortHeader
                        label="Source"
                        column="source"
                      />
                    </th>

                    <th className="px-4 py-3.5">
                      <SortHeader
                        label="Committed Fee"
                        column="committedFee"
                      />
                    </th>

                    <th className="px-4 py-3.5">
                      <SortHeader
                        label="Remark"
                        column="remark"
                      />
                    </th>

                    <th
                      className="w-[60px] px-3 py-3.5"
                      aria-label="Row actions"
                    />
                  </tr>
                </thead>

                <tbody>
                  {filteredEnquiries.map(
                    (item) => (
                      <tr
                        key={item.id}
                        onContextMenu={(event) =>
                          handleRightClick(
                            event,
                            item
                          )
                        }
                        className="border-b border-neutral-100 bg-white transition last:border-b-0 hover:bg-blue-50/30"
                      >
                        <td className="whitespace-nowrap px-4 py-3.5 text-neutral-700">
                          {formatDate(item.date)}
                        </td>

                        <td className="whitespace-nowrap px-4 py-3.5 font-medium text-neutral-900">
                          {item.name}
                        </td>

                        <td className="whitespace-nowrap px-4 py-3.5 text-neutral-700">
                          {item.contact}
                        </td>

                        <td className="whitespace-nowrap px-4 py-3.5 text-neutral-700">
                          {item.course}
                        </td>

                        <td className="whitespace-nowrap px-4 py-3.5 text-neutral-700">
                          {item.source}
                        </td>

                        <td className="whitespace-nowrap px-4 py-3.5 font-medium text-neutral-900">
                          ₹
                          {item.committedFee.toLocaleString(
                            "en-IN"
                          )}
                        </td>

                        <td className="max-w-[280px] px-4 py-3.5 text-neutral-600">
                          <div className="line-clamp-2">
                            {item.remark || "-"}
                          </div>
                        </td>

                        <td className="w-[60px] px-3 py-3.5 text-center">
                          <button
                            type="button"
                            onClick={(event) =>
                              handleActionButton(
                                event,
                                item
                              )
                            }
                            className="inline-flex h-8 w-8 items-center justify-center rounded-md text-neutral-500 transition hover:bg-blue-50 hover:text-blue-700"
                            aria-label={`Actions for ${item.name}`}
                          >
                            <EllipsisVertical
                              size={18}
                            />
                          </button>
                        </td>
                      </tr>
                    )
                  )}

                  {!filteredEnquiries.length && (
                    <tr>
                      <td
                        colSpan={8}
                        className="px-4 py-12 text-center text-sm text-neutral-500"
                      >
                        No enquiries found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </div>

      {/* ACTION MENU */}

      {actionMenu && (
        <div
          ref={actionMenuRef}
          style={{
            top: actionMenu.y,
            left: actionMenu.x,
          }}
          className="fixed z-50 w-[220px] rounded-xl border border-neutral-200 bg-white p-1.5 shadow-xl"
        >
          <div className="border-b border-neutral-100 px-3 py-2.5">
            <p className="truncate text-sm font-semibold text-neutral-900">
              {actionMenu.enquiry.name}
            </p>

            <p className="mt-0.5 text-xs text-neutral-400">
              {actionMenu.enquiry.id}
            </p>
          </div>

          <MenuButton
            icon={<Pencil size={16} />}
            label="Edit Enquiry"
            tone="blue"
            onClick={() =>
              editEnquiry(
                actionMenu.enquiry
              )
            }
          />

          <MenuButton
            icon={
              <UserRoundCheck size={16} />
            }
            label="Convert to Admission"
            tone="green"
            onClick={() =>
              convertEnquiry(
                actionMenu.enquiry
              )
            }
          />

          <div className="my-1 border-t border-neutral-100" />

          <MenuButton
            icon={<Trash2 size={16} />}
            label="Delete Enquiry"
            tone="red"
            onClick={() =>
              deleteEnquiry(
                actionMenu.enquiry
              )
            }
          />
        </div>
      )}
    </div>
  );
}

/* =========================================================
   SHARED COMPONENTS
========================================================= */

function SummaryCard({
  title,
  value,
  icon,
  tone,
}: {
  title: string;
  value: number;
  icon: ReactNode;
  tone: "blue" | "green" | "red";
}) {
  const toneClasses = {
    blue: {
      card: "border-blue-100 bg-blue-50/40",
      icon: "border-blue-100 bg-blue-50 text-blue-600",
      label: "text-blue-700",
    },
    green: {
      card: "border-green-100 bg-green-50/40",
      icon: "border-green-100 bg-green-50 text-green-600",
      label: "text-green-700",
    },
    red: {
      card: "border-red-100 bg-red-50/40",
      icon: "border-red-100 bg-red-50 text-red-600",
      label: "text-red-700",
    },
  }[tone];

  return (
    <div
      className={`rounded-xl border p-5 ${toneClasses.card}`}
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <p
            className={`text-sm font-medium ${toneClasses.label}`}
          >
            {title}
          </p>

          <p className="mt-2 text-3xl font-semibold tracking-tight text-neutral-900">
            {value}
          </p>
        </div>

        <span
          className={`inline-flex h-10 w-10 items-center justify-center rounded-lg border ${toneClasses.icon}`}
        >
          {icon}
        </span>
      </div>
    </div>
  );
}

function MenuButton({
  icon,
  label,
  onClick,
  tone,
}: {
  icon: ReactNode;
  label: string;
  onClick: () => void;
  tone: "blue" | "green" | "red";
}) {
  const classes =
    tone === "blue"
      ? "text-blue-700 hover:bg-blue-50"
      : tone === "green"
        ? "text-green-700 hover:bg-green-50"
        : "text-red-600 hover:bg-red-50";

  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm font-medium transition ${classes}`}
    >
      {icon}
      {label}
    </button>
  );
}
